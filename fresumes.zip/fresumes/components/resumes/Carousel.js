import { View, FlatList, StyleSheet, Dimensions, Text} from "react-native";
import StaticImage from "../StaticImage";
import PDFViewerComponent from "../PDFViewerComponent";
import { useState } from "react";

const dimensions = Dimensions.get('window');

/**
 * Check if a URL points to a PDF file
 * @param {string} url - The URL to check
 * @returns {boolean} - True if it's a PDF
 */
function isPDF(url) {
    return url.toLowerCase().includes('.pdf') || url.toLowerCase().includes('application/pdf');
}

export default Carousel = ({data, width, height}) => {
    const [pageIndex, setIndex] = useState(0)

    let multiplier = 1;
    if (dimensions.width >= 1000){
        multiplier = .4;
    }
    const cardWidth = dimensions.width * multiplier;

    const onScroll = (e) => {
        let offSet = e.nativeEvent.contentOffset.x;
        setIndex(Math.round(offSet/cardWidth))
    }

    const renderItem = (item) => {
        const url = item.item;
        
        // Check if this is a PDF file
        if (isPDF(url)) {
            return (
                <PDFViewerComponent 
                    url={url} 
                    width={width} 
                    height={height}
                    onDownload={() => {
                        if (typeof window !== 'undefined') {
                            const link = document.createElement('a');
                            link.href = url;
                            link.download = 'resume.pdf';
                            link.target = '_blank';
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                        }
                    }}
                />
            );
        }
        
        // Default to image display
        return <StaticImage url={url} width={width} height={height}/>;
    }

    return (
        <View>
            <FlatList horizontal 
            pagingEnabled = {true}
            showsHorizontalScrollIndicator = {false}
            bounces = {false} 
            style = {{width : "100%", aspectRatio: (width) / (height)}} 
            data = {data} 
            renderItem = {renderItem}
            onScroll = {onScroll}/>
            <View style = {styles.pagnationBox}>
                {   
                    data.length > 1 && data.map((item, index) => <Text flex = {0} key = {index} style = {{"fontSize" : "30px", "color" : index == pageIndex ? "black" : "grey"}}> • </Text>)
                }
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    "pagnationBox" : {
        flex: 1,
        width: "100%",
        justifyContent: "center",
        flexDirection: "row",
        display: "absolute",
        bottom: "55px"
    }
})