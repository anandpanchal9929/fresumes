import React, { useState, useEffect } from 'react';
import { View, TextInput, StyleSheet, ScrollView, Pressable, Text, Platform } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faSearch, faTimes, faHistory, faChevronDown } from '@fortawesome/free-solid-svg-icons';
import ModernTheme from '../../themes/ModernTheme';

const STATIC_SUGGESTIONS = [
    { type: 'job', label: 'Frontend Developer' },
    { type: 'job', label: 'Backend Developer' },
    { type: 'job', label: 'Full Stack Engineer' },
    { type: 'company', label: 'TechCorp' },
    { type: 'company', label: 'InnovateX' },
    { type: 'location', label: 'San Francisco' },
    { type: 'location', label: 'Remote' },
    { type: 'skill', label: 'React' },
    { type: 'skill', label: 'Node.js' },
    { type: 'skill', label: 'Python' },
    { type: 'job', label: 'Data Scientist' },
    { type: 'company', label: 'DataWorks' },
    { type: 'location', label: 'New York' },
    { type: 'location', label: 'London' },
];

function fetchSuggestions(query) {
    if (!query || query.length < 2) return [];
    const lower = query.toLowerCase();
    // Simulate backend: filter and rank by match
    return STATIC_SUGGESTIONS.filter(s => s.label.toLowerCase().includes(lower));
}

function highlightMatch(text, query, highlightStyle, normalStyle) {
    if (!query) return <Text style={normalStyle}>{text}</Text>;
    const lowerText = text.toLowerCase();
    const lowerQuery = query.toLowerCase();
    const start = lowerText.indexOf(lowerQuery);
    if (start === -1) return <Text style={normalStyle}>{text}</Text>;
    const end = start + query.length;
    return (
        <Text style={normalStyle}>
            {text.slice(0, start)}
            <Text style={highlightStyle}>{text.slice(start, end)}</Text>
            {text.slice(end)}
        </Text>
    );
}

const EnhancedSearch = ({ onSearch, onFilterChange, recentSearches = [] }) => {
    const [searchText, setSearchText] = useState('');
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [suggestions, setSuggestions] = useState([]);
    const [filters, setFilters] = useState({
        experience: '',
        skills: '',
        education: '',
        salary: '',
        location: '',
        remote: false,
        datePosted: '',
        sortBy: ''
    });
    const [activeDropdown, setActiveDropdown] = useState(null);

    useEffect(() => {
        if (searchText.length > 1) {
            // Fetch real-time, context-aware suggestions
            const results = fetchSuggestions(searchText);
            setSuggestions(results);
        } else {
            setSuggestions([]);
        }
    }, [searchText]);

    const handleSearch = (text) => {
        setSearchText(text);
        onSearch(text);
    };

    const handleFilterChange = (key, value) => {
        const newFilters = { ...filters, [key]: value };
        setFilters(newFilters);
        onFilterChange(newFilters);
        setActiveDropdown(null);
    };

    const clearSearch = () => {
        setSearchText('');
        setSuggestions([]);
        onSearch('');
    };

    const toggleDropdown = (dropdown) => {
        setActiveDropdown(activeDropdown === dropdown ? null : dropdown);
    };

    const clearAllFilters = () => {
        const clearedFilters = {
            experience: '',
            skills: '',
            education: '',
            salary: '',
            location: '',
            remote: false,
            datePosted: '',
            sortBy: ''
        };
        setFilters(clearedFilters);
        onFilterChange(clearedFilters);
    };

    const renderDropdown = (type) => {
        if (activeDropdown !== type) return null;

        const options = {
            experience: [
                { label: 'Entry Level', value: 'entry' },
                { label: '1-3 years', value: '1-3' },
                { label: '3-5 years', value: '3-5' },
                { label: '5+ years', value: '5+' }
            ],
            skills: [
                { label: 'Frontend Developer', value: 'frontend' },
                { label: 'Backend Developer', value: 'backend' },
                { label: 'Full Stack Developer', value: 'fullstack' },
                { label: 'Data Analyst', value: 'data_analyst' },
                { label: 'Data Scientist', value: 'data_scientist' }

            ],
            education: [
                { label: 'High School', value: 'high_school' },
                { label: 'Associate', value: 'associate' },
                { label: 'Bachelor', value: 'bachelor' },
                { label: 'Master', value: 'master' },
                { label: 'Doctorate', value: 'doctorate' }
            ],
            datePosted: [
                { label: 'Past 24 hours', value: '24h' },
                { label: 'Past week', value: 'week' },
                { label: 'Past month', value: 'month' },
                { label: 'Any time', value: 'any' }
            ],
            sortBy: [
                { label: 'Most relevant', value: 'relevant' },
                { label: 'Most recent', value: 'recent' },
                { label: 'Most viewed', value: 'viewed' }
            ]
        };
        if (!options[type]) return null;
        return (
            <View style={styles.dropdownContainer}>
                {options[type].map((option) => (
                    <Pressable
                        key={option.value}
                        style={styles.dropdownItem}
                        onPress={() => handleFilterChange(type, option.value)}
                        android_ripple={null}
                        android_disableSound={true}
                    >
                        <Text style={[
                            styles.dropdownItemText,
                            filters[type] === option.value && styles.dropdownItemTextActive
                        ]}>
                            {option.label}
                        </Text>
                    </Pressable>
                ))}
            </View>
        );
    };

    return (
        <View style={styles.container}>
            <View style={styles.searchContainer}>
                <FontAwesomeIcon 
                    icon={faSearch} 
                    style={styles.searchIcon} 
                    aria-label="Search"
                    focusable={false}
                />
                <TextInput
                    style={styles.input}
                    placeholder="Search resumes..."
                    value={searchText}
                    onChangeText={handleSearch}
                    onFocus={() => setShowSuggestions(true)}
                    {...(Platform.OS === 'web' ? {
                        style: {
                            ...styles.input,
                            WebkitTapHighlightColor: 'transparent',
                            WebkitUserSelect: 'none',
                            WebkitTouchCallout: 'none',
                            outline: 'none',
                            touchAction: 'manipulation',
                        }
                    } : {})}
                />
                {searchText ? (
                    <Pressable 
                        onPress={clearSearch} 
                        style={styles.clearButton}
                        android_ripple={null}
                        android_disableSound={true}
                    >
                        <FontAwesomeIcon 
                            icon={faTimes} 
                            color={ModernTheme.colors.grey[500]}
                            focusable={false}
                        />
                    </Pressable>
                ) : null}
            </View>

            {showSuggestions && suggestions.length > 0 && (
                <View style={styles.suggestionsDropdown}>
                    {['job', 'company', 'location', 'skill'].map((cat) => {
                        const catSuggestions = suggestions.filter(s => s.type === cat);
                        if (catSuggestions.length === 0) return null;
                        return (
                            <View key={cat}>
                                <Text style={styles.suggestionCategoryHeader}>{cat.charAt(0).toUpperCase() + cat.slice(1)}s</Text>
                                {catSuggestions.map((s, idx) => (
                                    <Pressable
                                        key={s.label + idx}
                                        style={styles.suggestionItem}
                                        onPress={() => {
                                            setSearchText(s.label);
                                            setShowSuggestions(false);
                                            onSearch(s.label);
                                        }}
                                    >
                                        <Text style={styles.suggestionText}>{highlightMatch(s.label, searchText, styles.suggestionHighlight, styles.suggestionText)}</Text>
                                    </Pressable>
                                ))}
                            </View>
                        );
                    })}
                </View>
            )}

            <ScrollView 
                horizontal 
                showsHorizontalScrollIndicator={false}
                style={styles.filtersContainer}
            >
                <Pressable
                    style={[styles.filterPill, filters.experience && styles.filterPillActive]}
                    onPress={() => toggleDropdown('experience')}
                    android_ripple={null}
                    android_disableSound={true}
                >
                    <Text style={[styles.filterPillText, filters.experience && styles.filterPillTextActive]}>
                        Experience
                    </Text>
                    <FontAwesomeIcon 
                        icon={faChevronDown} 
                        size={12} 
                        color={filters.experience ? ModernTheme.colors.white : ModernTheme.colors.grey[600]} 
                        style={styles.filterPillIcon}
                        focusable={false}
                    />
                </Pressable>

                <Pressable
                    style={[styles.filterPill, filters.skills && styles.filterPillActive]}
                    onPress={() => toggleDropdown('skills')}
                    android_ripple={null}
                    android_disableSound={true}
                >
                    <Text style={[styles.filterPillText, filters.skills && styles.filterPillTextActive]}>
                        Skills
                    </Text>
                    <FontAwesomeIcon 
                        icon={faChevronDown} 
                        size={12} 
                        color={filters.skills ? ModernTheme.colors.white : ModernTheme.colors.grey[600]} 
                        style={styles.filterPillIcon}
                        focusable={false}
                    />
                </Pressable>

                <Pressable
                    style={[styles.filterPill, filters.education && styles.filterPillActive]}
                    onPress={() => toggleDropdown('education')}
                    android_ripple={null}
                    android_disableSound={true}
                >
                    <Text style={[styles.filterPillText, filters.education && styles.filterPillTextActive]}>
                        Education
                    </Text>
                    <FontAwesomeIcon 
                        icon={faChevronDown} 
                        size={12} 
                        color={filters.education ? ModernTheme.colors.white : ModernTheme.colors.grey[600]} 
                        style={styles.filterPillIcon}
                        focusable={false}
                    />
                </Pressable>

                <Pressable
                    style={[styles.filterPill, filters.datePosted && styles.filterPillActive]}
                    onPress={() => toggleDropdown('datePosted')}
                    android_ripple={null}
                    android_disableSound={true}
                >
                    <Text style={[styles.filterPillText, filters.datePosted && styles.filterPillTextActive]}>
                        Date posted
                    </Text>
                    <FontAwesomeIcon 
                        icon={faChevronDown} 
                        size={12} 
                        color={filters.datePosted ? ModernTheme.colors.white : ModernTheme.colors.grey[600]} 
                        style={styles.filterPillIcon}
                        focusable={false}
                    />
                </Pressable>

                <Pressable
                    style={[styles.filterPill, filters.sortBy && styles.filterPillActive]}
                    onPress={() => toggleDropdown('sortBy')}
                    android_ripple={null}
                    android_disableSound={true}
                >
                    <Text style={[styles.filterPillText, filters.sortBy && styles.filterPillTextActive]}>
                        Sort by
                    </Text>
                    <FontAwesomeIcon 
                        icon={faChevronDown} 
                        size={12} 
                        color={filters.sortBy ? ModernTheme.colors.white : ModernTheme.colors.grey[600]} 
                        style={styles.filterPillIcon}
                        focusable={false}
                    />
                </Pressable>

                <Pressable
                    style={[styles.filterPill, styles.clearFiltersPill]}
                    onPress={clearAllFilters}
                    android_ripple={null}
                    android_disableSound={true}
                >
                    <Text style={[styles.filterPillText, styles.clearFiltersText]}>
                        Clear
                    </Text>
                </Pressable>
            </ScrollView>

            {renderDropdown(activeDropdown)}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        width: '100%',
        padding: ModernTheme.spacing.md,
        backgroundColor: ModernTheme.colors.white,
        ...(Platform.OS === 'web' ? {
            position: 'sticky',
            top: 0,
            zIndex: 1000,
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            touchAction: 'manipulation',
        } : {}),
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: ModernTheme.colors.grey[100],
        borderRadius: ModernTheme.borderRadius.lg,
        paddingHorizontal: ModernTheme.spacing.md,
        borderWidth: 1,
        borderColor: ModernTheme.colors.grey[200],
        width: 200,
        alignSelf: 'flex-start',
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            touchAction: 'manipulation',
        } : {}),
    },
    searchIcon: {
        marginRight: ModernTheme.spacing.sm,
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            pointerEvents: 'none',
        } : {}),
    },
    input: {
        height: 48,
        fontSize: ModernTheme.typography.fontSize.base,
        color: ModernTheme.colors.text.primary,
        width: '100%',
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
        } : {}),
    },
    clearButton: {
        padding: ModernTheme.spacing.xs,
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
            touchAction: 'manipulation',
        } : {}),
    },
    filtersContainer: {
        marginTop: ModernTheme.spacing.md,
        flexDirection: 'row',
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
        } : {}),
    },
    filterPill: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: ModernTheme.spacing.md,
        paddingVertical: ModernTheme.spacing.sm,
        borderRadius: ModernTheme.borderRadius.full,
        backgroundColor: ModernTheme.colors.button.background,
        marginRight: ModernTheme.spacing.sm,
        borderWidth: 1,
        borderColor: ModernTheme.colors.grey[300],
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            userSelect: 'none',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
            WebkitAppearance: 'none',
            touchAction: 'manipulation',
        } : {}),
    },
    filterPillActive: {
        backgroundColor: ModernTheme.colors.button.primary,
        borderColor: ModernTheme.colors.button.primary,
    },
    filterPillText: {
        fontSize: ModernTheme.typography.fontSize.sm,
        color: ModernTheme.colors.text.primary,
        fontWeight: '500',
    },
    filterPillTextActive: {
        color: ModernTheme.colors.button.text,
    },
    filterPillIcon: {
        marginLeft: ModernTheme.spacing.xs,
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            pointerEvents: 'none',
        } : {}),
    },
    dropdownContainer: {
        position: 'absolute',
        top: '100%',
        left: 0,
        right: 0,
        backgroundColor: ModernTheme.colors.white,
        borderRadius: ModernTheme.borderRadius.lg,
        borderWidth: 1,
        borderColor: ModernTheme.colors.grey[200],
        marginTop: ModernTheme.spacing.xs,
        ...(Platform.OS === 'web' ? {
            boxShadow: ModernTheme.shadows.md,
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            touchAction: 'manipulation',
        } : {
            elevation: 4,
        }),
    },
    dropdownItem: {
        padding: ModernTheme.spacing.md,
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            userSelect: 'none',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
            touchAction: 'manipulation',
            ':hover': {
                backgroundColor: ModernTheme.colors.grey[100],
            },
        } : {}),
    },
    dropdownItemText: {
        fontSize: ModernTheme.typography.fontSize.sm,
        color: ModernTheme.colors.text.primary,
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            pointerEvents: 'none',
        } : {}),
    },
    dropdownItemTextActive: {
        color: ModernTheme.colors.primary,
        fontWeight: '600',
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            pointerEvents: 'none',
        } : {}),
    },
    clearFiltersPill: {
        backgroundColor: ModernTheme.colors.red[500],
        borderColor: ModernTheme.colors.red[500],
        borderWidth: 1,
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            userSelect: 'none',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
            WebkitAppearance: 'none',
            touchAction: 'manipulation',
        } : {}),
    },
    clearFiltersText: {
        color: ModernTheme.colors.button.text,
        fontWeight: '500',
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            pointerEvents: 'none',
        } : {}),
    },
    suggestionsDropdown: {
        position: 'absolute',
        top: 56,
        left: 0,
        right: 0,
        backgroundColor: ModernTheme.colors.white,
        borderWidth: 1,
        borderColor: ModernTheme.colors.grey[200],
        borderRadius: ModernTheme.borderRadius.lg,
        zIndex: 2000,
        maxHeight: 240,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 4,
    },
    suggestionItem: {
        padding: ModernTheme.spacing.md,
        borderBottomWidth: 1,
        borderBottomColor: ModernTheme.colors.grey[100],
    },
    suggestionText: {
        fontSize: ModernTheme.typography.fontSize.base,
        color: ModernTheme.colors.text.primary,
    },
    suggestionType: {
        fontSize: ModernTheme.typography.fontSize.sm,
        color: ModernTheme.colors.grey[500],
    },
    suggestionCategoryHeader: {
        paddingVertical: ModernTheme.spacing.xs,
        paddingHorizontal: ModernTheme.spacing.md,
        backgroundColor: ModernTheme.colors.grey[50],
        color: ModernTheme.colors.grey[700],
        fontWeight: 'bold',
        fontSize: ModernTheme.typography.fontSize.sm,
    },
    suggestionHighlight: {
        backgroundColor: ModernTheme.colors.yellow[100] || '#fff9c4',
        color: ModernTheme.colors.primary || '#f59e42',
        fontWeight: 'bold',
    },
});

export default EnhancedSearch;