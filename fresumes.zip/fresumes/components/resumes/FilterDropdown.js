
import LightTheme from '../../themes/LightTheme';

import React, { useState } from 'react';
import { Pressable, Text, StyleSheet, View } from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker'

const SORT_OPTIONS = [
    {label: 'Newest', value: 'newest'},
    {label: 'Oldest', value: 'oldest'},
    {label: 'Most Downloaded', value: 'most_downloads'},
    {label: 'Least Downloaded', value: 'least_downloads'}
];

const STATES = [
    { label: 'Alabama', value: 'Alabama' },
    { label: 'Alaska', value: 'Alaska' },
    { label: 'American Samoa', value: 'American Samoa' },
    { label: 'Arizona', value: 'Arizona' },
    { label: 'Arkansas', value: 'Arkansas' },
    { label: 'California', value: 'California' },
    { label: 'Colorado', value: 'Colorado' },
    { label: 'Connecticut', value: 'Connecticut' },
    { label: 'Delaware', value: 'Delaware' },
    { label: 'District of Columbia', value: 'District of Columbia' },
    { label: 'Federated States of Micronesia', value: 'Federated States of Micronesia' },
    { label: 'Florida', value: 'Florida' },
    { label: 'Georgia', value: 'Georgia' },
    { label: 'Guam', value: 'Guam' },
    { label: 'Hawaii', value: 'Hawaii' },
    { label: 'Idaho', value: 'Idaho' },
    { label: 'Illinois', value: 'Illinois' },
    { label: 'Indiana', value: 'Indiana' },
    { label: 'Iowa', value: 'Iowa' },
    { label: 'Kansas', value: 'Kansas' },
    { label: 'Kentucky', value: 'Kentucky' },
    { label: 'Louisiana', value: 'Louisiana' },
    { label: 'Maine', value: 'Maine' },
    { label: 'Marshall Islands', value: 'Marshall Islands' },
    { label: 'Maryland', value: 'Maryland' },
    { label: 'Massachusetts', value: 'Massachusetts' },
    { label: 'Michigan', value: 'Michigan' },
    { label: 'Minnesota', value: 'Minnesota' },
    { label: 'Mississippi', value: 'Mississippi' },
    { label: 'Missouri', value: 'Missouri' },
    { label: 'Montana', value: 'Montana' },
    { label: 'Nebraska', value: 'Nebraska' },
    { label: 'Nevada', value: 'Nevada' },
    { label: 'New Hampshire', value: 'New Hampshire' },
    { label: 'New Jersey', value: 'New Jersey' },
    { label: 'New Mexico', value: 'New Mexico' },
    { label: 'New York', value: 'New York' },
    { label: 'North Carolina', value: 'North Carolina' },
    { label: 'North Dakota', value: 'North Dakota' },
    { label: 'Northern Mariana Islands', value: 'Northern Mariana Islands' },
    { label: 'Ohio', value: 'Ohio' },
    { label: 'Oklahoma', value: 'Oklahoma' },
    { label: 'Oregon', value: 'Oregon' },
    { label: 'Palau', value: 'Palau' },
    { label: 'Pennsylvania', value: 'Pennsylvania' },
    { label: 'Puerto Rico', value: 'Puerto Rico' },
    { label: 'Rhode Island', value: 'Rhode Island' },
    { label: 'South Carolina', value: 'South Carolina' },
    { label: 'South Dakota', value: 'South Dakota' },
    { label: 'Tennessee', value: 'Tennessee' },
    { label: 'Texas', value: 'Texas' },
    { label: 'Utah', value: 'Utah' },
    { label: 'Vermont', value: 'Vermont' },
    { label: 'Virgin Island', value: 'Virgin Island' },
    { label: 'Virginia', value: 'Virginia' },
    { label: 'Washington', value: 'Washington' },
    { label: 'West Virginia', value: 'West Virginia' },
    { label: 'Wisconsin', value: 'Wisconsin' },
    { label: 'Wyoming', value: 'Wyoming' }
]

/**
 * 
 * @param {object} style Any styles we want to use to style the overarching dropdown container.
 * @param {Query} query
 * @param {setQuery} setQuery
 * @returns 
 */
export function FilterDropdown({ style, query, setQuery, toggleDropdown}) {
    const [ skillsValue, setSkillsValue ] = useState(query.skills);
    const [ citiesValue, setCitiesValue ] = useState(query.cities);
    const [ statesValue, setStatesValue ] = useState(query.states);
    const [ sortByValue, setSortByValue ] = useState(null);

    const [ skillsOpen, setSkillsOpen ] = useState(false);
    const [ citiesOpen, setCitiesOpen ] = useState(false);
    const [ statesOpen, setStatesOpen ] = useState(false);
    const [ sortByOpen, setSortByOpen ] = useState(false);


    const [ skillItems, setSkillItems ] = useState([])
    const [ cityItems, setCityItems   ] = useState([])

    const dropdowns = [
        { name: 'Skills', setOpen: setSkillsOpen, setValue: setSkillsValue },
        { name: 'Cities', setOpen: setCitiesOpen, setValue: setCitiesValue },
        { name: 'States', setOpen: setStatesOpen, setValue: setStatesValue },
        { name: 'SortBy', setOpen: setSortByOpen, setValue: setSortByValue }
    ]

    const filterParams = {
        skills: skillsValue,
        cities: citiesValue,
        states: statesValue,
        sortBy: sortByValue
    }

    const closeAllSelectsExcept = (dropdownName) => {
        for(const dropdown of dropdowns) {
            if(dropdown.name != dropdownName) {
                dropdown.setOpen(false);
            }
        }
    }

    const onApplyFilters = () => {
        setQuery({
            ...query,
            ...filterParams
        });
        toggleDropdown()
    };

    const onClearFilters = () => {
        for(const dropdown of dropdowns) {
            dropdown.setValue(null);
        }
        setQuery({
            ...query,
            skills: null,
            cities: null,
            states: null,
            sortBy: null
        });
    };

    return <View style={[ styles.queryFormContainer, style ]}>
        <View style={[ styles.fieldContainer, styles.skillsFieldContainer ]}>
            <DropDownPicker
                open={skillsOpen}
                value={skillsValue}
                items={skillItems}
                setOpen={setSkillsOpen}
                setValue={setSkillsValue}
                setItems={setSkillItems}
                onOpen={() => closeAllSelectsExcept('Skills')}
                placeholder='Skills'
                searchable={true}
                searchPlaceholder="Type to add skill to filter..."
                multiple={true}
                addCustomItem={true}
                mode="BADGE"
                translation={{
                    NOTHING_TO_SHOW: "Add a skill using the input box to filter."
                  }}
                style={styles.dropdownInput}
            />
        </View>

        <View style={[ styles.fieldContainer, styles.citiesFieldContainer ]}>
            <DropDownPicker
                open={citiesOpen}
                value={citiesValue}
                items={cityItems}
                setOpen={setCitiesOpen}
                setValue={setCitiesValue}
                setItems={setCityItems}
                onOpen={() => closeAllSelectsExcept('Cities')}
                placeholder='Cities'
                searchable={true}
                searchPlaceholder="Type to add city to filter..."
                multiple={true}
                addCustomItem={true}
                mode="BADGE"
                translation={{
                    NOTHING_TO_SHOW: "Add a city using the input box to filter."
                  }}
                style={styles.dropdownInput}
            />
        </View>

        <View style={[ styles.fieldContainer, styles.statesFieldContainer ]}>
            <DropDownPicker
                open={statesOpen}
                value={statesValue}
                items={STATES}
                setOpen={setStatesOpen}
                setValue={setStatesValue}
                onOpen={() => closeAllSelectsExcept('States')}
                searchable={true}
                multiple={true}
                placeholder='State'
                mode="BADGE"
                searchPlaceholder="Search for states..."
                style={styles.dropdownInput}
            />
        </View>

        <View style={[ styles.fieldContainer, styles.sortByFieldContainer ]}>
            <DropDownPicker
                open={sortByOpen}
                value={sortByValue}
                items={SORT_OPTIONS}
                setOpen={setSortByOpen}
                setValue={setSortByValue}
                onOpen={() => closeAllSelectsExcept('SortBy')}
                placeholder = 'Sort By'
                searchPlaceholder='Select sorting option...'
                style={styles.dropdownInput}
            />
        </View>

        <View style={styles.buttonsContainer}>
            <Pressable 
                style={styles.buttonContainer}
                onPress={onClearFilters}>
                <Text style={styles.buttonText}>Clear</Text>
            </Pressable>

            <Pressable 
                style={styles.buttonContainer}
                onPress={onApplyFilters}>
                <Text style={styles.buttonText}>Apply</Text>
            </Pressable>
        </View>


    </View>
}


const styles = StyleSheet.create({
    buttonsContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 10
    }, 
    queryFormContainer: {
        shadowColor: LightTheme.colors.grey[900],
        shadowOffset: {
            width: 0,
            height: 10
        },
        shadowRadius: 10,
        shadowOpacity: 0.2,
        marginBottom: 30
    },  
    skillsFieldContainer: {
        zIndex: 300
    },
    citiesFieldContainer: {
        zIndex: 200
    },
    statesFieldContainer: {
        zIndex: 100
    },
    sortByFieldContainer: {
        zIndex: 50
    },
    fieldContainer: {
        rowGap: 5,
        marginHorizontal: 30,
        marginVertical: 10
    },
    dropdownInput: {
        backgroundColor: LightTheme.colors.grey[200],
        border: 'none'  
    },
    buttonContainer: {
        backgroundColor: LightTheme.colors.red[500],
        height: 30,
        borderRadius: 5,
        padding: 20,
        margin: 20,
        justifyContent: 'center',
        alignItems: 'center',
        alignSelf: 'flex-end'

    },
    buttonText: {
        color: LightTheme.colors.grey[100]
    }
})
