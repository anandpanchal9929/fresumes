/**
 * Render a static image where we already know the size of the image as we are going to render the image.
 */

import {Image, Dimensions} from 'react-native';
const dimensions = Dimensions.get('window');

/**
 * Load up a remote image and set the width to be 100%. The width and height have to be known before we load in the responsive
 * image.
 * @param {string} url The url we are loading the image from
 * @param {number} imageWidth The width in pixels of the image
 * @param {number} imageHeight The height in pixels of the image 
 * @returns 
 */

export default function StaticImage({url, width, height}) {
    let multiplier = 1;
    if (dimensions.width >= 1000){
        multiplier = .4;
    }
    return <Image style={{
            width : dimensions.width * multiplier,
            aspectRatio: (width) / (height)
        }} source={{
            uri: url
    }}/>
}