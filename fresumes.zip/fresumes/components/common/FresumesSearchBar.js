import React, { useState, useRef } from "react";
import { View, TextInput, Image, StyleSheet, ScrollView, Pressable, Text, Platform, FlatList, TouchableOpacity, ActivityIndicator } from "react-native";

const FILTER_TABS = [
  "Sort By", "Experience", "Language", "All filters", "Clear"
];

const API_BASE_URL = process.env.EXPO_PUBLIC_API_ORIGIN || 'http://localhost/v1';

async function fetchSuggestions(query) {
  if (!query || query.length < 2) return [];
  try {
    const API_BASE_URL = process.env.EXPO_PUBLIC_API_ORIGIN || 'http://localhost/v1';
    const response = await fetch(`${API_BASE_URL}/suggestions?q=${encodeURIComponent(query)}`);
    const data = await response.json();
    return data.suggestions || [];
  } catch (error) {
    console.error("Error fetching suggestions:", error);
    return [];
  }
}

// Helper function to parse natural language search queries
function parseNaturalLanguage(query) {
  const filters = {};
  const lowerQuery = query.toLowerCase();
  
  // Email detection
  const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/;
  const emailMatch = query.match(emailRegex);
  if (emailMatch) {
    filters.email = emailMatch[0];
  }

  // Experience level detection - enhanced with more variations
  if (lowerQuery.includes('entry') || lowerQuery.includes('junior') || lowerQuery.includes('beginner')) {
    filters.experience = 'Entry Level';
  } else if (lowerQuery.includes('senior') || lowerQuery.includes('5+') || lowerQuery.includes('expert')) {
    filters.experience = '5+ years';
  } else if (lowerQuery.includes('1-3') || lowerQuery.includes('1 to 3')) {
    filters.experience = '1-3 years';
  } else if (lowerQuery.includes('3-5') || lowerQuery.includes('3 to 5') || lowerQuery.includes('mid') || lowerQuery.includes('intermediate')) {
    filters.experience = '3-5 years';
  }
  
  // Date posted detection
  if (lowerQuery.includes('last 24 hours') || lowerQuery.includes('today') || lowerQuery.includes('24h')) {
    filters.datePosted = '24h';
  } else if (lowerQuery.includes('last week') || lowerQuery.includes('this week') || lowerQuery.includes('7 days')) {
    filters.datePosted = 'week';
  } else if (lowerQuery.includes('last month') || lowerQuery.includes('this month') || lowerQuery.includes('30 days')) {
    filters.datePosted = 'month';
  }
  
  // Sort by detection
  if (lowerQuery.includes('most recent') || lowerQuery.includes('newest')) {
    filters.sortBy = 'recent';
  } else if (lowerQuery.includes('most relevant')) {
    filters.sortBy = 'relevant';
  } else if (lowerQuery.includes('most viewed') || lowerQuery.includes('popular')) {
    filters.sortBy = 'viewed';
  }
  
  // Language detection - only natural languages
  const languages = [
    'english', 'hindi', 'russian', 'spanish', 'mandarin', 'french', 'arabic', 'bengali', 'portuguese'
  ];
  
  for (const lang of languages) {
    if (lowerQuery.includes(lang)) {
      filters.resume_language = lang.charAt(0).toUpperCase() + lang.slice(1);
      console.log('Detected resume_language:', filters.resume_language);
      break;
    }
  }
  
  // Programming languages detection - add to languages array
  const programmingLanguages = [
    'javascript', 'python', 'java', 'c++', 'c#', 'ruby', 'php', 'swift', 'kotlin', 
    'typescript', 'go', 'rust', 'scala', 'perl', 'r', 'dart', 'lua', 'haskell'
  ];
  
  const detectedLanguages = [];
  
  // Check for programming languages
  for (const lang of programmingLanguages) {
    if (lowerQuery.includes(lang)) {
      detectedLanguages.push(lang.charAt(0).toUpperCase() + lang.slice(1));
    }
  }
  
  if (detectedLanguages.length > 0) {
    filters.languages = detectedLanguages;
  }
  
  // Common skills detection
  const commonSkills = [
    'agile', 'scrum', 'kanban', 'leadership', 'management', 'communication', 'teamwork',
    'problem solving', 'critical thinking', 'project management', 'data analysis',
    'machine learning', 'ai', 'artificial intelligence', 'devops', 'cloud', 'aws', 'azure',
    'gcp', 'docker', 'kubernetes', 'ci/cd', 'testing', 'qa', 'ux', 'ui', 'design',
    'frontend', 'backend', 'fullstack', 'mobile', 'web', 'database', 'security'
  ];
  
  const detectedSkills = [];
  
  // Check for common skills
  for (const skill of commonSkills) {
    if (lowerQuery.includes(skill)) {
      detectedSkills.push(skill.charAt(0).toUpperCase() + skill.slice(1));
    }
  }
  
  if (detectedSkills.length > 0) {
    filters.skills = detectedSkills;
  }
  
  // Projects and achievements detection
  if (lowerQuery.includes('with projects') || lowerQuery.includes('has projects')) {
    filters.has_projects = 'yes';
  }
  
  if (lowerQuery.includes('with achievements') || lowerQuery.includes('has achievements')) {
    filters.has_achievements = 'yes';
  }
  
  // Sort by detection
  if (lowerQuery.includes('newest') || lowerQuery.includes('recent') || lowerQuery.includes('latest')) {
    filters.sortBy = 'Most recent';
  } else if (lowerQuery.includes('relevant')) {
    filters.sortBy = 'Most relevant';
  } else if (lowerQuery.includes('viewed')) {
    filters.sortBy = 'Most viewed';
  } else if (lowerQuery.includes('downloaded')) {
    filters.sortBy = 'Most Downloaded';
  }
  
  // Skills detection from explicit syntax
  const skillsMatch = lowerQuery.match(/skills?:\s*([\w\s,]+)/i);
  if (skillsMatch && skillsMatch[1]) {
    const skills = skillsMatch[1].split(',').map(s => s.trim()).filter(s => s.length > 0);
    if (skills.length > 0) {
      // Merge with any programming languages detected
      filters.skills = filters.skills ? [...filters.skills, ...skills] : skills;
    }
  }
  
  // Job titles detection - enhanced to catch more variations
  const jobTitlePatterns = [
    /job(s|\s+title(s)?):\s*([\w\s,]+)/i,  // Explicit job: syntax
    /position(s)?:\s*([\w\s,]+)/i,         // position: syntax
    /title(s)?:\s*([\w\s,]+)/i,            // title: syntax
    /role(s)?:\s*([\w\s,]+)/i              // role: syntax
  ];
  
  let jobTitles = [];
  for (const pattern of jobTitlePatterns) {
    const match = lowerQuery.match(pattern);
    if (match) {
      const lastGroup = match[match.length - 1];
      const titles = lastGroup.split(',').map(t => t.trim()).filter(t => t.length > 0);
      jobTitles = [...jobTitles, ...titles];
    }
  }
  
  // Common job titles detection
  const commonJobTitles = [
    'software engineer', 'developer', 'programmer', 'web developer', 'frontend developer',
    'backend developer', 'full stack', 'data scientist', 'data analyst', 'product manager',
    'project manager', 'ux designer', 'ui designer', 'devops engineer', 'qa engineer',
    'test engineer', 'systems administrator', 'network engineer', 'security engineer',
    'database administrator', 'dba', 'cloud engineer', 'mobile developer', 'ios developer',
    'android developer', 'react developer', 'angular developer', 'vue developer',
    'node developer', 'java developer', 'python developer', 'javascript developer',
    'c# developer', 'php developer', 'ruby developer', 'go developer', 'rust developer'
  ];
  
  for (const title of commonJobTitles) {
    if (lowerQuery.includes(title)) {
      jobTitles.push(title);
    }
  }
  
  if (jobTitles.length > 0) {
    filters.job_titles = [...new Set(jobTitles)]; // Remove duplicates
  }
  
  // Location detection - enhanced to catch more variations
  const locationPatterns = [
    /location(s)?:\s*([\w\s,]+)/i,    // location: syntax
    /city:\s*([\w\s,]+)/i,           // city: syntax
    /state:\s*([\w\s,]+)/i,          // state: syntax
    /country:\s*([\w\s,]+)/i,        // country: syntax
    /place:\s*([\w\s,]+)/i,          // place: syntax
    /area:\s*([\w\s,]+)/i            // area: syntax
  ];
  
  let locations = [];
  for (const pattern of locationPatterns) {
    const match = lowerQuery.match(pattern);
    if (match) {
      const lastGroup = match[match.length - 1];
      const locs = lastGroup.split(',').map(l => l.trim()).filter(l => l.length > 0);
      locations = [...locations, ...locs];
    }
  }
  
  // Try to detect locations without explicit syntax
  // This is a simplified approach - in a real app, you might use a location database
  const commonLocations = [
    'new york', 'san francisco', 'los angeles', 'chicago', 'seattle', 'austin',
    'boston', 'washington', 'atlanta', 'dallas', 'houston', 'miami', 'denver',
    'portland', 'philadelphia', 'phoenix', 'san diego', 'las vegas', 'nashville',
    'remote', 'work from home', 'wfh', 'hybrid'
  ];
  
  // Check for common locations in the query
  for (const loc of commonLocations) {
    if (lowerQuery.includes(loc) && 
        !lowerQuery.includes(`location:${loc}`) && 
        !lowerQuery.includes(`city:${loc}`) &&
        !lowerQuery.includes(`state:${loc}`) &&
        !lowerQuery.includes(`country:${loc}`)) {
      locations.push(loc);
    }
  }
  
  if (locations.length > 0) {
    filters.locations = [...new Set(locations)]; // Remove duplicates
  }
  
  // Education detection - enhanced with more variations
  const educationPatterns = [
    /education:\s*([\w\s,]+)/i,       // education: syntax
    /degree:\s*([\w\s,]+)/i,          // degree: syntax
    /qualification:\s*([\w\s,]+)/i     // qualification: syntax
  ];
  
  let educationValues = [];
  for (const pattern of educationPatterns) {
    const match = lowerQuery.match(pattern);
    if (match) {
      const lastGroup = match[match.length - 1];
      const eduList = lastGroup.split(',').map(e => e.trim()).filter(e => e.length > 0);
      educationValues = [...educationValues, ...eduList];
    }
  }
  
  // Common education levels
  const educationLevels = [
    'high school', 'associate', 'bachelor', 'master', 'phd', 'doctorate',
    'undergraduate', 'graduate', 'postgraduate', 'mba', 'bs', 'ba', 'ms', 'ma', 'phd'
  ];
  
  for (const edu of educationLevels) {
    if (lowerQuery.includes(edu) && 
        !lowerQuery.includes(`education:${edu}`) && 
        !lowerQuery.includes(`degree:${edu}`) &&
        !lowerQuery.includes(`qualification:${edu}`)) {
      educationValues.push(edu);
    }
  }
  
  if (educationValues.length > 0) {
    // Capitalize first letter of each education value
    filters.education = [...new Set(educationValues)].map(edu => 
      edu.charAt(0).toUpperCase() + edu.slice(1)
    );
  }
  
  // Name detection - enhanced to catch more variations
  const namePatterns = [
    /name:\s*([\w\s]+)/i,           // name: syntax
    /person:\s*([\w\s]+)/i,         // person: syntax
    /candidate:\s*([\w\s]+)/i       // candidate: syntax
  ];
  
  for (const pattern of namePatterns) {
    const match = lowerQuery.match(pattern);
    if (match && match[1]) {
      filters.name = match[1].trim();
      break;
    }
  }
  
  // Company detection - enhanced to catch more variations
  const companyPatterns = [
    /company:\s*([\w\s]+)/i,         // company: syntax
    /employer:\s*([\w\s]+)/i,        // employer: syntax
    /organization:\s*([\w\s]+)/i,    // organization: syntax
    /firm:\s*([\w\s]+)/i             // firm: syntax
  ];
  
  for (const pattern of companyPatterns) {
    const match = lowerQuery.match(pattern);
    if (match && match[1]) {
      filters.company = match[1].trim();
      break;
    }
  }
  
  // Email detection - enhanced to catch more variations
  const emailPatterns = [
    /email:\s*([^\s,;]+@[^\s,;]+\.[^\s,;]+)/i,  // email: syntax
    /e-mail:\s*([^\s,;]+@[^\s,;]+\.[^\s,;]+)/i,  // e-mail: syntax
    /([^\s,;]+@[^\s,;]+\.[^\s,;]+)/              // raw email format
  ];
  
  for (const pattern of emailPatterns) {
    const match = query.match(pattern); // Use original query to preserve case
    if (match && match[1]) {
      filters.email = match[1].trim();
      break;
    }
  }
  
  // Phone number detection - enhanced to catch more variations
  const phonePatterns = [
    /phone(\s+no\.?)?:\s*([\d\+\-\(\)\s]+)/i,  // phone: or phone no: syntax
    /telephone:\s*([\d\+\-\(\)\s]+)/i,           // telephone: syntax
    /mobile:\s*([\d\+\-\(\)\s]+)/i,              // mobile: syntax
    /cell:\s*([\d\+\-\(\)\s]+)/i,                // cell: syntax
    /\b(\+?[\d\-\(\)\s]{7,}\d)\b/                // raw phone format
  ];
  
  for (const pattern of phonePatterns) {
    const match = query.match(pattern); // Use original query to preserve formatting
    if (match) {
      const lastGroup = match[match.length - 1];
      filters.phone = lastGroup.trim().replace(/\s+/g, '');
      break;
    }
  }
  
  return filters;
}

export default function FresumesSearchBar({ onTabClick, onSearch, onFilterChange, selectedTab }) {
  const [searchText, setSearchText] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [recentSearches, setRecentSearches] = useState([]);
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [selectedSort, setSelectedSort] = useState("Most relevant");
  const [sortBtnLayout, setSortBtnLayout] = useState(null);
  const [showExperienceDropdown, setShowExperienceDropdown] = useState(false);
  const [selectedExperience, setSelectedExperience] = useState(null);
  const [experienceBtnLayout, setExperienceBtnLayout] = useState(null);
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const [languageBtnLayout, setLanguageBtnLayout] = useState(null);
  const [searchInputLayout, setSearchInputLayout] = useState(null);
  const [isSearching, setIsSearching] = useState(false);
  const inputRef = useRef();
  const sortBtnRef = useRef();
  const experienceBtnRef = useRef();
  const languageBtnRef = useRef();

  const SORT_OPTIONS = [
    "Most relevant",
    "Most recent",
    "Most viewed",
    "Most Downloaded"
  ];

  const EXPERIENCE_OPTIONS = [
    "Entry Level",
    "1-3 years",
    "3-5 years",
    "5+ years"
  ];

  const LANGUAGE_OPTIONS = [
    "English", "Hindi", "Russian", "Spanish", "Mandarin Chinese", "French", "Arabic", "Bengali", "Portuguese"
  ];
  

  const [suggestions, setSuggestions] = useState([]);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  // Unified filter state
  const [filterState, setFilterState] = useState({
    sortBy: "Most relevant",
    experience: null,
    resume_language: null,
    text: "",
    skills: [],
    job_titles: [],
    locations: [],
    education: [],
    name: "",
    company: "",
    email: "",
    phone: "",
    languages: [],
    certifications: [],
    has_projects: null,
    has_achievements: null,
    years_of_experience: null
  });

  // Helper to trigger filter change
  const triggerFilterChange = (newState) => {
    setFilterState(newState);
    if (onFilterChange) {
      // Map UI state to backend query params for Elasticsearch
      const query = {
        q: newState.text, // Changed from text to q to match backend API
        experience: newState.experience,
        resume_language: newState.resume_language,
        languages: newState.languages,
        certifications: newState.certifications,
        has_projects: newState.has_projects,
        has_achievements: newState.has_achievements,
        years_of_experience: newState.years_of_experience,
        sortBy: newState.sortBy === "Most recent" ? "recent" : 
                newState.sortBy === "Most relevant" ? "relevant" : 
                newState.sortBy === "Most viewed" ? "viewed" : 
                newState.sortBy === "Most Downloaded" ? "downloaded" : undefined,
        datePosted: newState.datePosted,
        advanced: true
      };
      
      // Add all filters from sidebar implementation
      if (newState.skills && newState.skills.length > 0) {
        query.skills = newState.skills;
      }
      
      if (newState.job_titles && newState.job_titles.length > 0) {
        query.job_titles = newState.job_titles;
      }
      
      if (newState.locations && newState.locations.length > 0) {
        query.locations = newState.locations;
      }
      
      if (newState.education && newState.education.length > 0) {
        query.education = newState.education;
      }
      
      if (newState.name) {
        query.name = newState.name;
      }
      
      if (newState.company) {
        query.company = newState.company;
      }
      
      // Add email and phone filters from sidebar
      if (newState.email) {
        query.email = newState.email;
      }
      
      if (newState.phone) {
        query.phone = newState.phone;
      }
      
      // Map UI sort options to backend sort parameters
      if (newState.sortBy) {
        query.sortBy = newState.sortBy;
        
        if (newState.sortBy === "Most relevant") {
          query.sortField = "_score";
          query.sortOrder = "desc";
        } else if (newState.sortBy === "Most recent") {
          query.sortField = "created_at";
          query.sortOrder = "desc";
        } else if (newState.sortBy === "Most viewed") {
          query.sortField = "views";
          query.sortOrder = "desc";
        } else if (newState.sortBy === "Most Downloaded") {
          query.sortField = "downloads";
          query.sortOrder = "desc";
        }
      }
      
      onFilterChange(query);
    }
  };

  // Update filter state on any change
  const handleSortChange = (option) => {
    triggerFilterChange({ ...filterState, sortBy: option });
  };
  const handleExperienceChange = (option) => {
    triggerFilterChange({ ...filterState, experience: option });
  };
  const handleLanguageChange = (option) => {
    console.log('Setting resume_language to:', option);
    triggerFilterChange({ ...filterState, resume_language: option });
  };
  const handleSearchChange = (text) => {
    setSearchText(text);
    setShowSuggestions(true);
    
    // Extract filters from natural language query
    const extractedFilters = parseNaturalLanguage(text);
    
    // Combine with existing filters
    const combinedFilters = {
      ...filterState,
      text: text,
      ...extractedFilters
    };
    
    triggerFilterChange(combinedFilters);
  };
  
  // Function to perform search when user presses Enter
  const handleSearchSubmit = () => {
    if (!searchText.trim()) return;
    
    setIsSearching(true);
    setShowSuggestions(false);
    
    // Add to recent searches
    setRecentSearches([searchText, ...recentSearches.filter(s => s !== searchText)].slice(0, 5));
    
    // Extract filters from natural language query
    const extractedFilters = parseNaturalLanguage(searchText);
    
    // Combine with existing filters
    const combinedFilters = {
      ...filterState,
      text: searchText,
      ...extractedFilters
    };
    
    // Update UI to reflect extracted filters
    if (extractedFilters.experience && !selectedExperience) {
      setSelectedExperience(extractedFilters.experience);
    }
    if (extractedFilters.resume_language && !selectedLanguage) {
      setSelectedLanguage(extractedFilters.resume_language);
    }
    if (extractedFilters.sortBy) {
      setSelectedSort(extractedFilters.sortBy);
    }
    if (extractedFilters.email) {
      console.log('Detected email in search:', extractedFilters.email);
    }
    if (extractedFilters.name) {
      console.log('Detected name in search:', extractedFilters.name);
    }
    
    // Ensure all filters are properly passed to the backend
    console.log('Search with all filters:', combinedFilters);
    
    // Log the combined filters for debugging
    console.log('Search submitted with filters:', combinedFilters);
    
    // Trigger search with combined filters
    triggerFilterChange(combinedFilters);
    
    if (onSearch) onSearch(searchText);
    
    // Reset searching state after a short delay
    setTimeout(() => {
      setIsSearching(false);
    }, 500);
  };

  React.useEffect(() => {
    if (searchText.length > 1) {
      setIsLoadingSuggestions(true);
      fetchSuggestions(searchText).then(suggestions => {
        setSuggestions(suggestions);
        setIsLoadingSuggestions(false);
      });
    } else {
      setSuggestions([]);
    }
  }, [searchText]);

  // Helper to close dropdown when clicking outside
  const renderSortDropdown = () => {
    if (!showSortDropdown || !sortBtnLayout) return null;
    return (
      <>
        <Pressable style={styles.dropdownOverlay} onPress={() => setShowSortDropdown(false)} />
        <View style={[styles.dropdownMenu, {
          position: 'absolute',
          top: sortBtnLayout.pageY + sortBtnLayout.height,
          left: sortBtnLayout.pageX,
        }]}
        >
          <Text style={styles.dropdownTitle}>Sort By</Text>
          {SORT_OPTIONS.map(option => (
            <Pressable
              key={option}
              style={styles.dropdownItem}
              onPress={() => {
                setSelectedSort(option);
                setShowSortDropdown(false);
                handleSortChange(option);
              }}
            >
              <View style={styles.checkboxContainer}>
                <View style={[styles.checkbox, selectedSort === option && styles.checkboxChecked]}>
                  {selectedSort === option && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.dropdownItemText}>{option}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      </>
    );
  };
  const renderExperienceDropdown = () => {
    if (!showExperienceDropdown || !experienceBtnLayout) return null;
    return (
      <>
        <Pressable style={styles.dropdownOverlay} onPress={() => setShowExperienceDropdown(false)} />
        <View style={[styles.dropdownMenu, {
          position: 'absolute',
          top: experienceBtnLayout.pageY + experienceBtnLayout.height,
          left: experienceBtnLayout.pageX,
        }]}
        >
          <Text style={styles.dropdownTitle}>Experience Level</Text>
          {EXPERIENCE_OPTIONS.map(option => (
            <Pressable
              key={option}
              style={styles.dropdownItem}
              onPress={() => {
                setSelectedExperience(option);
                setShowExperienceDropdown(false);
                handleExperienceChange(option);
              }}
            >
              <View style={styles.checkboxContainer}>
                <View style={[styles.checkbox, selectedExperience === option && styles.checkboxChecked]}>
                  {selectedExperience === option && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.dropdownItemText}>{option}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      </>
    );
  };
  const renderLanguageDropdown = () => {
    if (!showLanguageDropdown || !languageBtnLayout) return null;
    return (
      <>
        <Pressable style={styles.dropdownOverlay} onPress={() => setShowLanguageDropdown(false)} />
        <View style={[styles.dropdownMenu, {
          position: 'absolute',
          top: languageBtnLayout.pageY + languageBtnLayout.height,
          left: languageBtnLayout.pageX,
        }]}
        >
          <Text style={styles.dropdownTitle}>Language</Text>
          {LANGUAGE_OPTIONS.map(option => (
            <Pressable
              key={option}
              style={styles.dropdownItem}
              onPress={() => {
                setSelectedLanguage(option);
                setShowLanguageDropdown(false);
                handleLanguageChange(option);
              }}
            >
              <View style={styles.checkboxContainer}>
                <View style={[styles.checkbox, selectedLanguage === option && styles.checkboxChecked]}>
                  {selectedLanguage === option && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.dropdownItemText}>{option}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      </>
    );
  };
  


  // Helper to get the display name for each filter tab
  const getTabDisplayName = (tab) => {
    if (tab === "Sort By") {
      return selectedSort === "Most relevant" ? "Sort By" : `Sort By - ${selectedSort}`;
    }
    if (tab === "Experience") {
      return selectedExperience ? `Experience - ${selectedExperience}` : "Experience";
    }
    if (tab === "Language") {
      return selectedLanguage ? `Resume Language - ${selectedLanguage}` : "Resume Language";
    }
    return tab;
  };

  const isTabActive = (tab) => {
    if (tab === "Sort By") return selectedSort !== "Most relevant";
    if (tab === "Experience") return selectedExperience !== null;
    if (tab === "Language") return selectedLanguage !== null;
    return false;
  };

  const filteredSuggestions = suggestions;

  const handleSuggestionClick = (suggestion) => {
    setSearchText(suggestion.label);
    setShowSuggestions(false);
    
    // Add to recent searches
    setRecentSearches([suggestion.label, ...recentSearches.filter(s => s !== suggestion.label)].slice(0, 5));
    
    // Extract filters from natural language query
    const extractedFilters = parseNaturalLanguage(suggestion.label);
    
    // Combine with existing filters
    const combinedFilters = {
      ...filterState,
      text: suggestion.label,
      ...extractedFilters
    };
    
    // Update UI to reflect extracted filters
    if (extractedFilters.experience && !selectedExperience) {
      setSelectedExperience(extractedFilters.experience);
    }
    if (extractedFilters.language && !selectedLanguage) {
      setSelectedLanguage(extractedFilters.language);
    }
    if (extractedFilters.sortBy) {
      setSelectedSort(extractedFilters.sortBy);
    }
    
    // Log the combined filters for debugging
    console.log('Suggestion search with filters:', combinedFilters);
    
    // Trigger search with combined filters
    triggerFilterChange(combinedFilters);
    
    if (onSearch) onSearch(suggestion.label);
  };

  const handleRecentClick = (recent) => {
    setSearchText(recent);
    setShowSuggestions(false);
    
    // Extract filters from natural language query
    const extractedFilters = parseNaturalLanguage(recent);
    
    // Combine with existing filters
    const combinedFilters = {
      ...filterState,
      text: recent,
      ...extractedFilters
    };
    
    // Update UI to reflect extracted filters
    if (extractedFilters.experience && !selectedExperience) {
      setSelectedExperience(extractedFilters.experience);
    }
    if (extractedFilters.language && !selectedLanguage) {
      setSelectedLanguage(extractedFilters.language);
    }
    if (extractedFilters.sortBy) {
      setSelectedSort(extractedFilters.sortBy);
    }
    
    // Log the combined filters for debugging
    console.log('Recent search with filters:', combinedFilters);
    
    // Trigger search with combined filters
    triggerFilterChange(combinedFilters);
    
    if (onSearch) onSearch(recent);
  };

  // Render suggestions as a separate overlay
  const renderSuggestions = () => {
    if (!showSuggestions || !searchInputLayout || (filteredSuggestions.length === 0 && recentSearches.length === 0)) {
      return null;
    }

    return (
      <>
        <Pressable 
          style={styles.suggestionsOverlay} 
          onPress={() => setShowSuggestions(false)}
        />
        <View style={[styles.suggestionsDropdown, {
          position: 'absolute',
          top: searchInputLayout.pageY + searchInputLayout.height + 4,
          left: searchInputLayout.pageX + (searchInputLayout.width * 0.1),
          width: searchInputLayout.width * 0.8,
          marginLeft: 0,
          paddingLeft: 0,
        }]}>
          {filteredSuggestions.length > 0 && (
            <View>
              {filteredSuggestions.map((s, i) => (
                <Pressable 
                  key={s.label + i} 
                  style={styles.suggestionItem} 
                  onPress={() => handleSuggestionClick(s)}
                >
                  <Text style={styles.suggestionText}>{s.label}</Text>
                  <Text style={styles.suggestionType}>{s.type}</Text>
                </Pressable>
              ))}
            </View>
          )}
          {recentSearches.length > 0 && (
            <View style={styles.recentSection}>
              <Text style={styles.recentTitle}>Recent</Text>
              {recentSearches.map((r, i) => (
                <Pressable 
                  key={r + i} 
                  style={styles.suggestionItem} 
                  onPress={() => handleRecentClick(r)}
                >
                  <Text style={styles.suggestionText}>{r}</Text>
                </Pressable>
              ))}
            </View>
          )}
        </View>
      </>
    );
  };

  // Helper function to display active filters as a hint
  const getSearchPlaceholder = () => {
    const activeFilters = [];
    
    if (filterState.skills && filterState.skills.length > 0) {
      activeFilters.push(`Skills: ${filterState.skills.join(', ')}`);
    }
    
    if (filterState.job_titles && filterState.job_titles.length > 0) {
      activeFilters.push(`Jobs: ${filterState.job_titles.join(', ')}`);
    }
    
    if (filterState.experience) {
      activeFilters.push(`Experience: ${filterState.experience}`);
    }
    
    if (filterState.language) {
      activeFilters.push(`Language: ${filterState.language}`);
    }
    
    if (activeFilters.length > 0) {
      return `Search with ${activeFilters.join(' | ')}`;
    }
    
    return "Search Resumes";
  };

  return (
    <View style={styles.container}>
      <View style={styles.searchRow}>
       <a href="/" style={{ display: 'flex' , alignItems: 'center' }}>
	<Image source={require('../../assets/logo.png')} style={styles.logo} />
	</a>
        <View style={{ flex: 1, position: 'relative' }}>
          <View style={styles.searchInputContainer}>
            <View style={styles.inputWithClear}>
              <TextInput
                ref={inputRef}
                style={styles.searchInput}
                placeholder={getSearchPlaceholder()}
                placeholderTextColor="#666"
                value={searchText}
                onChangeText={handleSearchChange}
                onFocus={() => setShowSuggestions(true)}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                onSubmitEditing={handleSearchSubmit}
                returnKeyType="search"
                onLayout={(e) => {
                  const { x, y, width, height } = e.nativeEvent.layout;
                  setSearchInputLayout({ width, height, pageX: x, pageY: y });
                }}
              />
              {searchText ? (
                <TouchableOpacity 
                  style={styles.clearButton}
                  onPress={() => {
                    setSearchText('');
                    setShowSuggestions(false);
                    // Trigger a complete reset of search results when clearing the search text
                    triggerFilterChange({
                      sortBy: "Most relevant",
                      experience: null,
                      language: null,
                      text: "",
                      skills: [],
                      job_titles: [],
                      locations: [],
                      education: [],
                      name: "",
                      company: "",
                      email: "",
                      phone: ""
                    });
                    // Force a refresh of the search results
                    if (onSearch) onSearch("");
                  }}
                >
                  <Text style={styles.clearButtonText}>×</Text>
                </TouchableOpacity>
              ) : null}
            </View>
            <TouchableOpacity 
              style={styles.searchButton} 
              onPress={handleSearchSubmit}
              disabled={isSearching}
            >
              {isSearching ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <Text style={styles.searchButtonText}>Search</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsRow}>
        {FILTER_TABS.map((tab, i) => (
          <View key={tab} style={{ position: 'relative' }}>
          <Pressable
              ref={
                tab === "Sort By" ? sortBtnRef :
                tab === "Experience" ? experienceBtnRef :
                tab === "Language" ? languageBtnRef :
                tab === "Skills" ? skillsBtnRef : undefined
              }
              style={[
                styles.tabBtn,
                isTabActive(tab) && styles.activeTabBtn,
                tab === "All filters" && styles.allFiltersBtn,
                tab === "Clear" && styles.clearTabBtn,
                selectedTab === tab && styles.selectedTab
              ]}
              onPress={() => {
                if (tab === "Clear") {
                  // Reset all state in the search bar
                  setSearchText("");
                  setShowSortDropdown(false);
                  setShowExperienceDropdown(false);
                  setShowLanguageDropdown(false);
                  setSelectedSort("Most relevant");
                  setSelectedExperience(null);
                  setSelectedLanguage(null);
                  
                  // Reset all filters with empty object (original working implementation)
                  // This will reset all filters including sidebar filters:
                  // jobs, education, skills, name, email, phone, location, company, job_titles, locations
                  const resetState = {
                    sortBy: "Most relevant",
                    experience: null,
                    resume_language: null,
                    text: "",
                    skills: [],
                    job_titles: [],
                    locations: [],
                    education: [],
                    name: "",
                    company: "",
                    email: "",
                    phone: "",
                    languages: [],
                    certifications: [],
                    has_projects: null,
                    has_achievements: null,
                    years_of_experience: null
                  };
                  setFilterState(resetState);
                  if (onFilterChange) onFilterChange({});
                  
                  // Force a refresh of the search results
                  if (onSearch) onSearch("");
                  
                  // Notify parent component about tab click (for sidebar filters)
                  // This will trigger any additional sidebar filter resets in the parent component
                  if (onTabClick) onTabClick(tab);
                } else if (tab === "Sort By") {
                  setShowExperienceDropdown(false);
                  setShowLanguageDropdown(false);
                  if (!showSortDropdown && sortBtnRef.current) {
                    sortBtnRef.current.measure((fx, fy, width, height, px, py) => {
                      setSortBtnLayout({ width, height, pageX: px, pageY: py });
                      setShowSortDropdown(true);
                    });
                  } else {
                    setShowSortDropdown(false);
                  }
                } else if (tab === "Experience") {
                  setShowSortDropdown(false);
                  setShowLanguageDropdown(false);
                  if (!showExperienceDropdown && experienceBtnRef.current) {
                    experienceBtnRef.current.measure((fx, fy, width, height, px, py) => {
                      setExperienceBtnLayout({ width, height, pageX: px, pageY: py });
                      setShowExperienceDropdown(true);
                    });
                  } else {
                    setShowExperienceDropdown(false);
                  }
                } else if (tab === "Language") {
                  setShowSortDropdown(false);
                  setShowExperienceDropdown(false);
                  if (!showLanguageDropdown && languageBtnRef.current) {
                    languageBtnRef.current.measure((fx, fy, width, height, px, py) => {
                      setLanguageBtnLayout({ width, height, pageX: px, pageY: py });
                      setShowLanguageDropdown(true);
                    });
                  } else {
                    setShowLanguageDropdown(false);
                  }

                } else {
                  setShowSortDropdown(false);
                  setShowExperienceDropdown(false);
                  setShowLanguageDropdown(false);
                  if (onTabClick) onTabClick(tab);
                }
              }}
              onLayout={(e) => {
                if (tab === "Sort By") {
                  if (!sortBtnRef.current) {
                    const { x, y, width, height } = e.nativeEvent.layout;
                    setSortBtnLayout({ width, height, pageX: x, pageY: y });
                  }
                } else if (tab === "Experience") {
                   if (!experienceBtnRef.current) {
                    const { x, y, width, height } = e.nativeEvent.layout;
                    setExperienceBtnLayout({ width, height, pageX: x, pageY: y });
                  }
                } else if (tab === "Language") {
                  if (!languageBtnRef.current) {
                    const { x, y, width, height } = e.nativeEvent.layout;
                    setLanguageBtnLayout({ width, height, pageX: x, pageY: y });
                  }
                }
              }}
            >
              <Text style={styles.tabText}>{getTabDisplayName(tab)}</Text>
          </Pressable>
          </View>
        ))}
      </ScrollView>
      {renderSortDropdown()}
      {renderExperienceDropdown()}
      {renderLanguageDropdown()}
      {renderSuggestions()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 10,
    boxShadow: Platform.OS === 'web' ? '0 2px 8px rgba(0,0,0,0.04)' : undefined,
    zIndex: 10,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  logo: {
    width: 36,
    height: 36,
    marginRight: 8,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  inputWithClear: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    fontSize: 16,
    backgroundColor: '#f3f6f8',
    color: '#222',
  },
  clearButton: {
    position: 'absolute',
    right: 8,
    top: 8,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FF1149',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
    cursor: 'pointer',
  },
  clearButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    lineHeight: 20,
  },
  searchButton: {
    height: 40,
    backgroundColor: "#FF1149",
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 15,
    marginLeft: 8,
  },
  searchButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  suggestionsDropdown: {
    position: 'absolute',
    backgroundColor: '#fff',
    borderRadius: 8,
    boxShadow: Platform.OS === 'web' ? '0 4px 16px rgba(0,0,0,0.10)' : undefined,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    zIndex: 3000,
    paddingVertical: 4,
    paddingHorizontal: 0,
    maxHeight: 220,
    marginTop: 0,
    marginLeft: 0,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  suggestionText: {
    fontSize: 15,
    color: '#222',
  },
  suggestionType: {
    fontSize: 12,
    color: '#888',
    marginLeft: 8,
  },
  recentSection: {
    marginTop: 6,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 4,
  },
  recentTitle: {
    fontSize: 13,
    color: '#888',
    marginLeft: 12,
    marginBottom: 2,
  },
  tabsRow: {
    flexDirection: 'row',
    marginTop: 2,
  },
  tabBtn: {
    backgroundColor: '#FF1149',
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 18,
    marginRight: 8,
    marginBottom: 2,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  allFiltersBtn: {
    backgroundColor: '#FF1149',
    borderWidth: 1,
    borderColor: '#bdbdbd',
    fontWeight: '500',
  },
  selectedTab: {
    backgroundColor: '#e0e0e0',
    borderColor: '#d0d0d0',
  },
  activeTabBtn: {
    backgroundColor: '#FF1149', // Themed active color (light pink)
    borderColor: '#FF1149', // Themed active border color (dark pink)
    borderWidth: 1,
  },
  clearTabBtn: {
    backgroundColor: '#FF1149',
    borderColor: '#999',
    borderWidth: 1,
    cursor: 'pointer',
    zIndex: 5,
  },
  tabText: {
    fontSize: 15,
    color: '#fff',
  },
  dropdownMenu: {
    position: 'absolute',
    top: 40,
    left: 0,
    backgroundColor: '#FF1149',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    zIndex: 2001,
    minWidth: 180,
    paddingVertical: 8,
    paddingHorizontal: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  dropdownOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2000,
    backgroundColor: 'transparent',
  },
  dropdownTitle: {
    fontWeight: 'bold',
    fontSize: 15,
    marginBottom: 8,
    marginLeft: 16,
    color: '#fff',
  },
  dropdownItem: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: 18,
    height: 18,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#bdbdbd',
    marginRight: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  checkboxChecked: {
    backgroundColor: '#FF1149', // dark pink
    borderColor: '#FF1149',
  },
  checkboxTick: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    lineHeight: 16,
  },
  dropdownItemText: {
    fontSize: 15,
    color: '#fff',
  },
  suggestionsOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2999,
    backgroundColor: 'transparent',
  },
});
