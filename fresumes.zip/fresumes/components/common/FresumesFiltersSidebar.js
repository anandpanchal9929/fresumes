import React, { useState, useEffect } from "react";
import { View, Text, Pressable, StyleSheet, ScrollView, Platform, TextInput, FlatList, ActivityIndicator } from "react-native";

const EDUCATION = [
  "High School",
  "Associate",
  "Bachelor",
  "Master",
  "Doctorate"
];

const YES_NO_OPTIONS = ["yes", "no"];

const API_BASE_URL = process.env.EXPO_PUBLIC_API_ORIGIN || 'http://localhost/v1';

async function fetchSkillSuggestions(query) {
  if (!query || query.length < 1) return [];
  try {
    const response = await fetch(`${API_BASE_URL}/suggestions?q=${encodeURIComponent(query)}`);
    const data = await response.json();
    return (data.suggestions || []).filter(s => s.type === 'skill').map(s => s.label);
  } catch (error) {
    return [];
  }
}

export default function FresumesFiltersSidebar({ onClose, onFilterChange }) {
  const [selectedJobs, setSelectedJobs] = useState([]);
  const [selectedEducation, setSelectedEducation] = useState([]);
  const [selectedSkills, setSelectedSkills] = useState([]);
  const [skillInput, setSkillInput] = useState("");
  const [skillSuggestions, setSkillSuggestions] = useState([]);
  const [isSkillLoading, setIsSkillLoading] = useState(false);

  // New text input states
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [location, setLocation] = useState("");
  const [company, setCompany] = useState("");
  const [emailError, setEmailError] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [hasProjects, setHasProjects] = useState("");
  const [hasAchievements, setHasAchievements] = useState("");

  const [selectedJobTitles, setSelectedJobTitles] = useState([]);
  const [jobTitleInput, setJobTitleInput] = useState("");
  const [jobTitleSuggestions, setJobTitleSuggestions] = useState([]);
  const [isJobTitleLoading, setIsJobTitleLoading] = useState(false);

  const [selectedLocations, setSelectedLocations] = useState([]);
  const [locationInput, setLocationInput] = useState("");
  const [locationSuggestions, setLocationSuggestions] = useState([]);
  const [isLocationLoading, setIsLocationLoading] = useState(false);

  const validateEmail = (text) => {
    if (text && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text)) {
      setEmailError("Please enter a valid email address.");
    } else {
      setEmailError("");
    }
  };

  const validatePhone = (text) => {
    if (text && !/^\+?[0-9]*$/.test(text)) {
      setPhoneError("Please enter a valid phone number.");
    } else {
      setPhoneError("");
    }
  };

  const handleEmailChange = (text) => {
    setEmail(text);
    validateEmail(text);
  };

  const handlePhoneChange = (text) => {
    setPhone(text);
    validatePhone(text);
  };

  const clearAll = () => {
    setSelectedJobTitles([]);
    setSelectedEducation([]);
    setSelectedSkills([]);
    setSelectedLocations([]);
    setName("");
    setEmail("");
    setPhone("");
    setCompany("");
    setHasProjects("");
    setHasAchievements("");
    setSkillInput("");
    setLocationInput("");
    setJobTitleInput("");
    setSkillSuggestions([]);
    setLocationSuggestions([]);
    setJobTitleSuggestions([]);
    setEmailError("");
    setPhoneError("");
    if (onFilterChange) {
      onFilterChange({});
    }
  };

  const handleMultiSelect = (value, selected, setSelected) => {
    if (selected.includes(value)) {
      setSelected(selected.filter(v => v !== value));
    } else {
      setSelected([...selected, value]);
    }
  };

  const handleSingleSelect = (value, selected, setSelected) => {
    setSelected(selected === value ? '' : value);
  };

  useEffect(() => {
    if (skillInput.length > 0) {
      setIsSkillLoading(true);
      fetchSkillSuggestions(skillInput).then(suggestions => {
        setSkillSuggestions(suggestions);
        setIsSkillLoading(false);
      });
    } else {
      setSkillSuggestions([]);
    }
  }, [skillInput]);

  async function fetchJobTitleSuggestions(query) {
    if (!query || query.length < 1) return [];
    try {
      const response = await fetch(`${API_BASE_URL}/suggestions?q=${encodeURIComponent(query)}`);
      const data = await response.json();
      return (data.suggestions || []).filter(s => s.type === 'job').map(s => s.label);
    } catch (error) {
      return [];
    }
  }

  useEffect(() => {
    if (jobTitleInput.length > 0) {
      setIsJobTitleLoading(true);
      fetchJobTitleSuggestions(jobTitleInput).then(suggestions => {
        setJobTitleSuggestions(suggestions);
        setIsJobTitleLoading(false);
      });
    } else {
      setJobTitleSuggestions([]);
    }
  }, [jobTitleInput]);

  async function fetchLocationSuggestions(query) {
    if (!query || query.length < 1) return [];
    try {
      const response = await fetch(`${API_BASE_URL}/suggestions?q=${encodeURIComponent(query)}`);
      const data = await response.json();
      return (data.suggestions || []).filter(s => s.type === 'location').map(s => s.label);
    } catch (error) {
      return [];
    }
  }

  useEffect(() => {
    if (locationInput.length > 0) {
      setIsLocationLoading(true);
      fetchLocationSuggestions(locationInput).then(suggestions => {
        setLocationSuggestions(suggestions);
        setIsLocationLoading(false);
      });
    } else {
      setLocationSuggestions([]);
    }
  }, [locationInput]);

  // Update filters when any value changes
  React.useEffect(() => {
    if (onFilterChange) {
      // Only include non-empty values to avoid sending empty filters
      const filters = {};
      
      if (selectedJobTitles.length > 0) filters.job_titles = selectedJobTitles;
      if (selectedEducation.length > 0) filters.education = selectedEducation;
      if (selectedSkills.length > 0) filters.skills = selectedSkills;
      if (selectedLocations.length > 0) filters.locations = selectedLocations;
      if (name) filters.name = name;
      if (email) filters.email = email;
      if (phone) filters.phone = phone;
      if (company) filters.company = company;
      if (hasProjects) filters.has_projects = hasProjects;
      if (hasAchievements) filters.has_achievements = hasAchievements;
      
      console.log('Sending filters from sidebar:', filters);
      onFilterChange(filters);
    }
    // eslint-disable-next-line
  }, [selectedJobTitles, selectedEducation, selectedSkills, selectedLocations, name, email, phone, company, hasProjects, hasAchievements]);

  return (
    <View style={styles.sidebar}>
      <View style={styles.headerRow}>
        <Text style={styles.headerText}>Filter only</Text>
        <Text style={styles.dropdown}>RESUMES </Text>
        <Text style={styles.headerText}>by</Text>
        <Pressable onPress={onClose} style={styles.closeBtn}><Text style={styles.closeBtnText}>✕</Text></Pressable>
      </View>
      <ScrollView style={{flex: 1}} contentContainerStyle={{paddingBottom: 80}}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Skills</Text>
          <TextInput
            style={styles.input}
            value={skillInput}
            onChangeText={setSkillInput}
            placeholder="Type to search skills"
            placeholderTextColor="#adadad"
          />
          {isSkillLoading && <ActivityIndicator size="small" color="#e91e63" />}
          {skillSuggestions.length > 0 && (
            <FlatList
              data={skillSuggestions}
              keyExtractor={item => item}
              renderItem={({ item }) => (
                <Pressable
                  style={styles.suggestionItem}
                  onPress={() => {
                    if (!selectedSkills.includes(item)) setSelectedSkills([...selectedSkills, item]);
                    setSkillInput("");
                    setSkillSuggestions([]);
                  }}
                >
                  <Text style={styles.suggestionText}>{item}</Text>
                </Pressable>
              )}
              style={styles.suggestionList}
            />
          )}
          <View style={styles.selectedSkillsContainer}>
            {selectedSkills.map(skill => (
              <Pressable key={skill} style={styles.selectedSkill} onPress={() => setSelectedSkills(selectedSkills.filter(s => s !== skill))}>
                <Text style={styles.selectedSkillText}>{skill} ✕</Text>
              </Pressable>
            ))}
          </View>
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Name</Text>
          <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Enter name" placeholderTextColor="#adadad" />
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Email</Text>
          <TextInput
            style={[styles.input, emailError ? styles.inputError : null]}
            value={email}
            onChangeText={handleEmailChange}
            placeholder="Enter email"
            keyboardType="email-address"
            placeholderTextColor="#adadad"
          />
          {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Phone No.</Text>
          <TextInput
            style={[styles.input, phoneError ? styles.inputError : null]}
            value={phone}
            onChangeText={handlePhoneChange}
            placeholder="Enter phone number"
            keyboardType="phone-pad"
            placeholderTextColor="#adadad"
          />
          {phoneError ? <Text style={styles.errorText}>{phoneError}</Text> : null}
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Location</Text>
          <TextInput
            style={styles.input}
            value={locationInput}
            onChangeText={setLocationInput}
            placeholder="Type to search locations"
            placeholderTextColor="#adadad"
          />
          {isLocationLoading && <ActivityIndicator size="small" color="#e91e63" />}
          {locationSuggestions.length > 0 && (
            <FlatList
              data={locationSuggestions}
              keyExtractor={item => item}
              renderItem={({ item }) => (
                <Pressable
                  style={styles.suggestionItem}
                  onPress={() => {
                    if (!selectedLocations.includes(item)) setSelectedLocations([...selectedLocations, item]);
                    setLocationInput("");
                    setLocationSuggestions([]);
                  }}
                >
                  <Text style={styles.suggestionText}>{item}</Text>
                </Pressable>
              )}
              style={styles.suggestionList}
            />
          )}
          <View style={styles.selectedSkillsContainer}>
            {selectedLocations.map(loc => (
              <Pressable key={loc} style={styles.selectedSkill} onPress={() => setSelectedLocations(selectedLocations.filter(s => s !== loc))}>
                <Text style={styles.selectedSkillText}>{loc} ✕</Text>
              </Pressable>
            ))}
          </View>
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Company</Text>
          <TextInput style={styles.input} value={company} onChangeText={setCompany} placeholder="Enter company" placeholderTextColor="#adadad" />
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Job Titles</Text>
          <TextInput
            style={styles.input}
            value={jobTitleInput}
            onChangeText={setJobTitleInput}
            placeholder="Type to search job titles"
            placeholderTextColor="#adadad"
          />
          {isJobTitleLoading && <ActivityIndicator size="small" color="#e91e63" />}
          {jobTitleSuggestions.length > 0 && (
            <FlatList
              data={jobTitleSuggestions}
              keyExtractor={item => item}
              renderItem={({ item }) => (
                <Pressable
                  style={styles.suggestionItem}
                  onPress={() => {
                    if (!selectedJobTitles.includes(item)) setSelectedJobTitles([...selectedJobTitles, item]);
                    setJobTitleInput("");
                    setJobTitleSuggestions([]);
                  }}
                >
                  <Text style={styles.suggestionText}>{item}</Text>
                </Pressable>
              )}
              style={styles.suggestionList}
            />
          )}
          <View style={styles.selectedSkillsContainer}>
            {selectedJobTitles.map(title => (
              <Pressable key={title} style={styles.selectedSkill} onPress={() => setSelectedJobTitles(selectedJobTitles.filter(s => s !== title))}>
                <Text style={styles.selectedSkillText}>{title} ✕</Text>
              </Pressable>
            ))}
          </View>
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Education</Text>
          <View style={styles.checkboxGroup}>
            {EDUCATION.map(ed => (
              <Pressable key={ed} style={[styles.checkboxRow, selectedEducation.includes(ed) && styles.selectedBtn]} onPress={() => handleMultiSelect(ed, selectedEducation, setSelectedEducation)}>
                <View style={[styles.checkbox, selectedEducation.includes(ed) && styles.checkboxSelected]}>
                  {selectedEducation.includes(ed) && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.checkboxLabel}>{ed}</Text>
              </Pressable>
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Has Projects</Text>
          <View style={styles.checkboxGroup}>
            {YES_NO_OPTIONS.map(option => (
              <Pressable
                key={option}
                style={styles.checkboxRow}
                onPress={() => {
                  setHasProjects(hasProjects === option ? "" : option);
                }}
              >
                <View style={[styles.checkbox, hasProjects === option && styles.checkboxSelected]}>
                  {hasProjects === option && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.checkboxLabel}>{option === "yes" ? "Yes" : "No"}</Text>
              </Pressable>
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Has Achievements</Text>
          <View style={styles.checkboxGroup}>
            {YES_NO_OPTIONS.map(option => (
              <Pressable
                key={option}
                style={styles.checkboxRow}
                onPress={() => {
                  setHasAchievements(hasAchievements === option ? "" : option);
                }}
              >
                <View style={[styles.checkbox, hasAchievements === option && styles.checkboxSelected]}>
                  {hasAchievements === option && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.checkboxLabel}>{option === "yes" ? "Yes" : "No"}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      </ScrollView>
      <View style={styles.footerRow}>
        <Pressable style={styles.resetBtn} onPress={clearAll}><Text style={styles.resetText}>Clear All</Text></Pressable>
        <Pressable style={styles.showResultsBtn} onPress={onClose}><Text style={styles.showResultsText}>Show results</Text></Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  sidebar: {
    width: 340,
    backgroundColor: '#fff',
    borderRadius: 12,
    boxShadow: Platform.OS === 'web' ? '0 2px 8px rgba(0,0,0,0.08)' : undefined,
    paddingVertical: 24,
    paddingHorizontal: 24,
    fontFamily: 'Segoe UI',
    zIndex: 100,
    position: 'fixed',
    right: 0,
    top: 0,
    bottom: 0,
    minHeight: 400,
    maxHeight: '100vh',
    overflow: 'auto',
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 18,
  },
  headerText: {
    fontSize: 17,
    fontWeight: '500',
    color: '#222',
  },
  dropdown: {
    marginHorizontal: 4,
    color: '#666',
    fontSize: 16,
  },
  closeBtn: {
    marginLeft: 'auto',
    padding: 4,
  },
  closeBtnText: {
    fontSize: 20,
    color: '#888',
  },
  input: {
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    backgroundColor: '#f3f6f8',
  },
  inputError: {
    borderColor: '#e53935', // red for error
  },
  errorText: {
    color: '#e53935', // red for error
    fontSize: 12,
    marginTop: 4,
  },
  section: {
    marginBottom: 18,
  },
  sectionTitle: {
    fontWeight: '600',
    marginBottom: 8,
    fontSize: 15,
  },
  connectionsRow: {
    flexDirection: 'row',
    gap: 8,
  },
  connectionBtn: {
    backgroundColor: '#f3f6f8',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 16,
    paddingVertical: 4,
    paddingHorizontal: 12,
    fontSize: 15,
    marginRight: 8,
  },
  checkboxGroup: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    minWidth: 160,
    marginBottom: 4,
    borderRadius: 6,
    paddingVertical: 2,
    paddingHorizontal: 2,
  },
  checkbox: {
    width: 18,
    height: 18,
    borderWidth: 1,
    borderColor: '#bbb',
    borderRadius: 4,
    marginRight: 6,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkboxSelected: {
    backgroundColor: '#FF1149', // dark pink
    borderColor: '#FF1149',
  },
  checkboxTick: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  checkboxLabel: {
    fontSize: 15,
    color: '#222',
  },
  addLink: {
    color: '#0a66c2',
    fontSize: 15,
    marginTop: 6,
    marginBottom: 2,
  },
  selectedBtn: {
    backgroundColor: '#FF1149', // light pink
  },
  footerRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 10,
    marginTop: 18,
    position: 'absolute',
    bottom: 16,
    right: 24,
    left: 24,
    backgroundColor: '#fff',
    paddingTop: 8,
  },
  resetBtn: {
    backgroundColor: 'transparent',
    borderWidth: 0,
    paddingVertical: 6,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginRight: 4,
  },
  resetText: {
    color: '#666',
    fontSize: 16,
  },
  showResultsBtn: {
    backgroundColor: '#FF1149', // dark pink
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 22,
  },
  showResultsText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
  },
  suggestionItem: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  suggestionText: {
    fontSize: 15,
    color: '#333',
  },
  suggestionList: {
    maxHeight: 150,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    overflow: 'hidden',
  },
  selectedSkillsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 8,
  },
  selectedSkill: {
    backgroundColor: '#FF1149',
    borderRadius: 16,
    paddingVertical: 4,
    paddingHorizontal: 10,
  },
  selectedSkillText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '500',
  },
});
