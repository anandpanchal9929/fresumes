import React, { useState } from 'react';
import "@chatscope/chat-ui-kit-styles/dist/default/styles.min.css";
import { MainContainer, ChatContainer, MessageList, Message, MessageInput, TypingIndicator, Avatar } from "@chatscope/chat-ui-kit-react";
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native'; 

const API_KEY = "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";
const systemMessage = {
  "role": "system", "content": "Hello, you are FresumesAI, an AI designed to simulate job interviews and provide feedback to job seekers, when asked with unrelated questions such as give me a number do not entertain it and remember your task as an ai chatbot only used for resume feedback or interviewing candidates. Start by gathering key information about the user to personalize the interview process. Begin by asking their name, current job role or education, years of experience, and relevant skills. Then, ask about their career goals and the specific job or industry they are aiming for. Once the user's background is clear, tailor your questions accordingly. Start with common interview questions that align with the job role and industry the user has specified. As you ask each question, assess their response in terms of communication skills, clarity, relevance to the job, and how well they highlight their qualifications and experience. After each answer, provide constructive feedback on areas they can improve. This may include refining their focus on specific achievements, better showcasing technical skills or soft skills, or aligning their responses with the company's mission and goals. Additionally, offer general tips on body language, tone, and confidence, reminding them to stay concise and focused on the most relevant experiences. Encourage the user to view the interview as a conversation, where they can also ask questions and express their enthusiasm for the role. If they seem uncertain or nervous, offer encouragement and suggest ways to build their confidence. In addition to interview preparation, also assist job seekers in improving their resumes. Ask them to upload or describe their resume, and offer detailed feedback on its content. Focus on the clarity, relevance, and impact of their resume. Highlight any missing details that could improve their chances, such as quantifiable achievements, technical skills, or specific industry knowledge. Provide suggestions to make their language more action-oriented and professional, ensuring the formatting is clean, easy to read, and aligned with industry standards.Your tone should always be supportive and insightful, aiming to build the user's confidence while helping them refine their resume and interview skills. As you provide feedback, ensure that the user feels motivated to improve without feeling overwhelmed. Help them prepare for their future job with actionable advice that empowers them."
};

export default function Interview() {
  const [messages, setMessages] = useState([
    {
      message: "Auto deploying with Webhooks!",
      sentTime: "just now",
      sender: "ChatGPT",
      direction: "incoming"
    }
  ]);
  
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = async (message) => {
    const newMessage = {
      message,
      direction: 'outgoing',
      sender: "user"
    };

    const newMessages = [...messages, newMessage];

    setMessages(newMessages);

    setIsTyping(true);
    await processMessageToChatGPT(newMessages);
  };

  async function processMessageToChatGPT(chatMessages) {
    let apiMessages = chatMessages.map((messageObject) => {
      let role = messageObject.sender === "ChatGPT" ? "assistant" : "user";
      return { role: role, content: messageObject.message };
    });

    const apiRequestBody = {
      "model": "gpt-3.5-turbo",
      "messages": [
        systemMessage,
        ...apiMessages
      ]
    };

    await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": "Bearer " + API_KEY,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(apiRequestBody)
    }).then((data) => data.json())
    .then((data) => {
      setMessages([...chatMessages, {
        message: data.choices[0].message.content,
        sender: "ChatGPT",
        direction: "incoming"
      }]);
      setIsTyping(false);
    });
  }


  return (
    <View style={styles.app}>
      
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton}>
          <a href='/' style={styles.backButtonText}>《</a>
        </TouchableOpacity>
        <Text style={styles.headerText}>FresumesAI</Text>
      </View>

      {/* Chat Section */}
      <View style={styles.chatContainer}>
        <MainContainer>
          <ChatContainer>       
            <MessageList 
              scrollBehavior="smooth" 
              typingIndicator={isTyping ? <TypingIndicator content="ChatGPT is typing" /> : null}
            >
              {messages.map((message, i) => {
                return (
                  <Message 
                    key={i} 
                    model={{
                      message: message.message,
                      sentTime: message.sentTime,
                      sender: message.sender,
                      direction: message.direction,
                      position: "normal"
                    }}
                    style={styles.messageSpacing} // Add the style here
                  >
                    {/* Show Avatar only if the message is from FresumesAI (ChatGPT) */}
                    {message.sender === "ChatGPT" && (
                      <Avatar 
                        src="https://fresumes.com/app/assets/assets/logo.25ef68fec4816b06fb49334b77dd073e.png" 
                        size="md"  
                        status='available'
                      />
                    )}
                  </Message>
                );
              })}
            </MessageList>
            <MessageInput placeholder="Type message here" onSend={handleSend} />        
          </ChatContainer>
        </MainContainer>
      </View>
    </View>
  );
}

// Define the styles using StyleSheet.create
const styles = StyleSheet.create({
  app: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  header: {
    width: '100%',
    backgroundColor: 'white',
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',  // Added for proper alignment of back button and title
  },
  backButton: {
    position: 'absolute',
    left: 10,  // Position the back button to the left
  },
  backButtonText: {
    fontSize: 24,
    color: 'red',  // Make the back button red
    fontWeight: 'bold',  // Make the back button bold
    textDecorationLine: 'none'
  },
  headerText: {
    fontSize: 20,
    color: "red",
    fontWeight: 'bold',
  },
  chatContainer: {
    position: 'relative',
    height: '80vh',
    width: '90vw',
    maxWidth: 1200,
    border: '1px solid #ccc',
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
    padding: 10,
    marginTop: 20,
  },
  messageSpacing: {
    marginTop: 10,
    marginBottom: 5 // Add space between messages
  }
});
