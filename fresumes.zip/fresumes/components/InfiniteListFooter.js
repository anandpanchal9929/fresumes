/**
 * This component renders a footer element for the infinite list.
 */

import LightTheme from '../themes/LightTheme';

import React, { ActivityIndicator, StyleSheet, Text } from 'react-native';

/**
 * @return {React.ReactElement}
 */
export default function InfiniteListFooter() {
    return <>
        <ActivityIndicator size='large' color={LightTheme.primary}/>
    </>
}

const styles = StyleSheet.create({
    activityIndicatorContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center'
    },logo: {
        width: 20,
        height: 20
    },
    bodyText: {
        fontSize: 16,
        color: LightTheme.text
    }
});