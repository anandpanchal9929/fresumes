const pathPrefix = process.env.PATH_PREFIX;

module.exports = ({ config }) => {
    if(pathPrefix === undefined) {
        return config
    }

    return {
      ...config,
      experiments: {
        baseUrl: `/${pathPrefix}`
      }
    };
  };
