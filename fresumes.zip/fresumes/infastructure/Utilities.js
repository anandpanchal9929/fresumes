/**
 * Utilities files for additions to the bass Node.JS API specifically for infastructure components.
 */

/**
 * Decode html characters in a string in order to turn them into their relgualr UTF-8 couterpart.
 * @param {string} html Html we are looking to decode.
 * @returns String without any special html characters.
 */
export const decodeHTMLEncodedSpecialChars = (html) => {
   const htmlEntities = {
       "&amp;" : "&",
       "&lt;" : "<",
       "&gt;" : ">",
       "&quot;" : '"',
       "&apos;" : "'"
   };
   return html.replace(/(&amp;|&lt;|&gt;|&quot;|&apos;)/g, (match) => htmlEntities[match] );
}
