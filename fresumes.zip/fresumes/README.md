# Fresumes App
Welcome to the fresumes application! A free resume database designed with the candidates in mind.
This README.md will guide you through some of the basic installation and design choices
surronding our applicaitonl.

## Starting the Application
First start by using the current version of Node for the project.
```
nvm use
```

Then launch expo using the following command.
```
npx expo start
```

To launch the web version run the following command.
```
npx expo start --web
```

## Building the Application
Use the following command to build the application for the web. This uses metro to bundle the
application for web instead of webpack and it also writes our Google Analytics tag to the output.
```
bash build.bash
```
