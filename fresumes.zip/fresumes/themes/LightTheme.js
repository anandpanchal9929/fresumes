/**
 * This file holds the theme data for our application. We can use this throughout components to 
 * have a global access point to change colors.
 * 
 * @todo We should consider adding fonts here as well. We could also add some default spacing as
 * well.
 */   

const colorPalette = {
    grey: {
        100: '#FFFFFF',
        200: '#F3F3F8',
        300: '#E3E3EC',
        400: '#CDCDD9',
        500: '#B0AFBE',
        600: '#898997',
        700: '#5B5B67',
        800: '#2B2B32',
        900: '#000000'
    },
    red: {
        100: '#FFF2F5',
        200: '#FFD1DC',
        300: '#FFA0B7',
        400: '#FF5E85',
        500: '#FF1049',
        600: '#C2002E',
        700: '#860020',
        800: '#490011',
        900: '#0D0003'
    }
}

export default {
    background          : "#EFEFEF",
    backgroundSecondary : colorPalette.grey[100],
    primary             : colorPalette.red[500],
    secondary           : "#000000",
    text                : "#5A5A5A",
    textLight           : "#999999",

    colors: colorPalette
}
