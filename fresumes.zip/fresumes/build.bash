#!/bin/bash

GOOGLE_ANALYTICS_ID=$(grep GOOGLE_ANALYTICS_ID= .env | awk '{split($0, a, "="); print a[2]}')
GOOGLE_ADS_ID=$(grep GOOGLE_ADS_ID= .env | awk '{split($0, a, "="); print a[2]}')
read -r -d '' GOOGLE_SCRIPTS << html
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=$GOOGLE_ANALYTICS_ID"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '$GOOGLE_ANALYTICS_ID');
    </script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=$GOOGLE_ADS_ID" crossorigin="anonymous"></script>
  </head>
html
# https://www.unix.com/shell-programming-and-scripting/270369-how-escape-all-special-characters.html
GOOGLE_SCRIPTS_ESCAPED=$(echo "$GOOGLE_SCRIPTS" | sed 's/[&\/]/\\&/g' | sed -z 's/\n/\\n/g')

# Set the correct node version.
export NVM_DIR=$HOME/.nvm;
source $NVM_DIR/nvm.sh;
nvm use

npx expo export -p web

# Install Google Analytics
sed -zi "s/<\/head>/$GOOGLE_SCRIPTS_ESCAPED/g" dist/index.html

