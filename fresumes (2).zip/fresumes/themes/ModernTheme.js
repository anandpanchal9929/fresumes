export default {
    colors: {
        primary: '#FF1049',
        secondary: '#FF5E85',
        accent: '#FFA0B7',
        background: '#FFFFFF',
        backgroundSecondary: '#F3F4F6',
        white: '#FFFFFF',
        text: {
            primary: '#1F2937',
            secondary: '#4B5563',
            light: '#9CA3AF'
        },
        success: '#10B981',
        error: '#FF1049',
        warning: '#F59E0B',
        red: {
            100: '#FFF2F5',
            200: '#FFD1DC',
            300: '#FFA0B7',
            400: '#FF5E85',
            500: '#FF1049',
            600: '#C2002E',
            700: '#860020',
            800: '#490011',
            900: '#0D0003'
        },
        grey: {
            100: '#F3F4F6',
            200: '#E5E7EB',
            300: '#D1D5DB',
            400: '#9CA3AF',
            500: '#6B7280',
            600: '#4B5563',
            700: '#374151',
            800: '#1F2937',
            900: '#111827'
        },
        button: {
            primary: '#FF1049', // red[500]
            text: '#F3F4F6', // grey[100]
            background: '#E5E7EB' // grey[200]
        }
    },
    shadows: {
        sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
        md: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
        lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
    },
    borderRadius: {
        sm: '0.25rem',
        md: '0.375rem',
        lg: '0.5rem',
        xl: '0.75rem',
        full: '9999px'
    },
    spacing: {
        xs: '0.25rem',
        sm: '0.5rem',
        md: '1rem',
        lg: '1.5rem',
        xl: '2rem'
    },
    typography: {
        fontFamily: {
            primary: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
            secondary: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif'
        },
        fontSize: {
            xs: '0.75rem',
            sm: '0.875rem',
            base: '1rem',
            lg: '1.125rem',
            xl: '1.25rem',
            '2xl': '1.5rem',
            '3xl': '1.875rem',
            '4xl': '2.25rem'
        }
    },
    transitions: {
        default: 'all 0.3s ease',
        fast: 'all 0.15s ease',
        slow: 'all 0.5s ease'
    },
    breakpoints: {
        sm: '640px',
        md: '768px',
        lg: '1024px',
        xl: '1280px',
        '2xl': '1536px'
    }
}; 