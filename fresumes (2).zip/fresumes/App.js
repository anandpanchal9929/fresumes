/**
 * 
 */

import ListView from "./components/resumes/ListView";
import Interview from "./components/Interview";
import { StyleSheet, View, Platform } from 'react-native';

const globalStyles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
});

export default function App() {
    const path = window.location.pathname.toLowerCase();
    if (path === "/interview") {
        return <Interview />;
    } else {
        return (
            <View style={globalStyles.container}>
                <ListView />
            </View>
        );
    }
}