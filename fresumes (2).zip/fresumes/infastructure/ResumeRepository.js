/**
 * This file provides a way for users to search for new resumes in our database through applying
 * specific filters for the data they want.
 */

/**
 * @param {object} obj
 * @returns {string[]} An array of the parameters from the object that we will use as query param
 * input to the backend.
 */
function objectToQueryParamArray(obj) {
    const params = [];

    for (const [key, value] of Object.entries(obj)) {
        if (value != null && value !== '' && value !== undefined) {
            if (Array.isArray(value)) {
                // Handle arrays properly - send as comma-separated values
                if (value.length > 0) {
                    params.push(`${encodeURIComponent(key)}=${encodeURIComponent(value.join(','))}`);
                }
            } else {
                params.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
            }
        }
    }

    return params;
}

/**
 * @param {Query} query
 * @param {number} page The page of the results we are currently searching for
 * @returns {object[]} The mapped resume cards for the UI.
 */
const API_BASE_URL = process.env.EXPO_PUBLIC_API_ORIGIN || 'http://localhost/v1';

export async function findAll(query, page) {
  // Temporary debug log to see what query is being sent
  console.log('[Frontend] Query being sent:', query);

  // Only log the actual API request for fetching resumes
  let endpoint = '/resumes';
  let queryParams = { page, limit: 3 };

  // Check if any advanced filters are present (including empty arrays)
  const hasAdvancedFilters =
    (query.skills && Array.isArray(query.skills) && query.skills.length > 0) ||
    (query.experience && query.experience !== '') ||
    (query.education && Array.isArray(query.education) && query.education.length > 0) ||
    (query.datePosted && query.datePosted !== '') ||
    (query.sortBy && query.sortBy !== '') ||
    (query.job_titles && Array.isArray(query.job_titles) && query.job_titles.length > 0) ||
    (query.locations && Array.isArray(query.locations) && query.locations.length > 0);

  if (hasAdvancedFilters) {
    endpoint = '/resumes/advanced-search';
    if (query.text) queryParams.q = query.text;
    if (query.skills && Array.isArray(query.skills) && query.skills.length > 0) queryParams.skills = query.skills;
    if (query.job_titles && Array.isArray(query.job_titles) && query.job_titles.length > 0) queryParams.job_titles = query.job_titles;
    if (query.experience && query.experience !== '') queryParams.experience = query.experience;
    if (query.education && Array.isArray(query.education) && query.education.length > 0) queryParams.education = query.education;
    if (query.datePosted && query.datePosted !== '') queryParams.datePosted = query.datePosted;
    if (query.sortBy && query.sortBy !== '') queryParams.sortBy = query.sortBy;
    if (query.locations && Array.isArray(query.locations) && query.locations.length > 0) queryParams.locations = query.locations;
    if (query.cities && Array.isArray(query.cities) && query.cities.length > 0) queryParams.location = query.cities.join(',');
    if (query.states && Array.isArray(query.states) && query.states.length > 0) queryParams.location = query.states.join(',');
  } else {
    if (query.text) queryParams.q = query.text;
    if (query.sortBy && query.sortBy !== '') queryParams.sortBy = query.sortBy;
    if (query.skills && Array.isArray(query.skills) && query.skills.length > 0) queryParams.skills = query.skills;
    if (query.job_titles && Array.isArray(query.job_titles) && query.job_titles.length > 0) queryParams.job_titles = query.job_titles;
    if (query.locations && Array.isArray(query.locations) && query.locations.length > 0) queryParams.locations = query.locations;
  }

  const queryParamArray = objectToQueryParamArray(queryParams);
  const queryString = queryParamArray.join('&');
  const fullUrl = `${API_BASE_URL}${endpoint}?${queryString}`;

  // This is the only log that should remain
  console.log('[Resume API Request]', fullUrl);

  // Fetch the resumes from the backend using the correct endpoint
  const response = await fetch(fullUrl);
  const result = await response.json();

  if (!Array.isArray(result)) {
    return [];
  }

  // Map backend resumes to frontend card format, always using /v1/download/:id for PDF
  return result.map((resume, idx) => ({
    key: resume._id || resume.id || idx,
    url: [[`${API_BASE_URL}/download/${resume._id || resume.id}`]],
    download_url: `${API_BASE_URL}/download/${resume._id || resume.id}`,
    width: 800,
    height: 800,
    ...resume
  }));
}
