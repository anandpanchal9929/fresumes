# PDF Viewer Component

## Overview

The PDF Viewer component has been upgraded to provide a LinkedIn-like PDF viewing experience with enhanced features and better cross-platform support.

## Features

### Web Platform (react-pdf)
- **Page Navigation**: Navigate between pages with arrow buttons
- **Zoom Controls**: Zoom in/out from 50% to 300%
- **Fullscreen Mode**: Toggle fullscreen viewing
- **External View**: Open PDF in new tab
- **Download**: Direct download functionality
- **Responsive Design**: Adapts to container size
- **Loading States**: Proper loading and error handling

### Mobile Platform (react-native-pdf)
- **Native PDF Rendering**: Uses platform-native PDF viewers
- **Touch Gestures**: Pinch to zoom, swipe to navigate
- **Performance Optimized**: Hardware-accelerated rendering

### Fallback Support
- **Iframe Fallback**: Falls back to browser iframe if PDF libraries fail to load
- **Error Handling**: Graceful error handling with retry options

## Installation

The following packages are required:

```bash
npm install react-pdf@^7.0.0 pdfjs-dist@^3.11.174 react-native-pdf@^6.6.2 react-native-blob-util@^0.19.6
```

## Usage

### Basic Usage

```javascript
import PDFViewerComponent from './components/PDFViewerComponent';

<PDFViewerComponent
    url="https://example.com/resume.pdf"
    width={400}
    height={600}
    onDownload={() => {
        // Custom download handler
        console.log('Downloading PDF...');
    }}
/>
```

### In ListViewCard

The `ListViewCard` component automatically uses the improved PDF viewer:

```javascript
// The component automatically detects PDF files and uses the enhanced viewer
<ListViewCard item={resumeItem} />
```

### In Carousel

The `Carousel` component also supports the enhanced PDF viewer:

```javascript
// PDF files in carousels will use the enhanced viewer
<Carousel data={pdfUrls} width={300} height={400} />
```

## Component Props

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `url` | string | Yes | URL of the PDF file to display |
| `width` | number/string | Yes | Width of the container |
| `height` | number/string | Yes | Height of the container |
| `onDownload` | function | No | Callback for download action |

## Controls

### Page Navigation
- **Previous Page** (‹): Navigate to previous page
- **Page Info**: Shows current page and total pages
- **Next Page** (›): Navigate to next page

### Zoom Controls
- **Zoom Out** (-): Decrease zoom level
- **Zoom Level**: Shows current zoom percentage
- **Zoom In** (+): Increase zoom level

### Action Controls
- **Fullscreen** (⤢/⤡): Toggle fullscreen mode
- **External View** (👁): Open in new tab
- **Download** (⬇): Download the PDF

## Styling

The component uses the `LightTheme` for consistent styling and supports:

- **Responsive Design**: Adapts to different screen sizes
- **Hover Effects**: Interactive hover states on web
- **Smooth Transitions**: CSS transitions for better UX
- **Accessibility**: Proper ARIA labels and keyboard navigation

## Browser Support

### Web
- Chrome/Chromium (recommended)
- Firefox
- Safari
- Edge

### Mobile
- iOS (react-native-pdf)
- Android (react-native-pdf)

## Troubleshooting

### PDF Not Loading
1. Check if the URL is accessible
2. Verify CORS settings on the server
3. Check browser console for errors
4. Try the fallback iframe mode

### Performance Issues
1. Use appropriate image sizes
2. Consider lazy loading for large PDFs
3. Optimize PDF file sizes

### Mobile Issues
1. Ensure react-native-pdf is properly linked
2. Check file permissions on Android
3. Verify iOS deployment settings

## Migration from Old Version

The new PDF viewer is backward compatible. Existing code will automatically use the enhanced features:

```javascript
// Old code still works
<PDFViewerComponent url={pdfUrl} width={400} height={600} />

// New features are automatically available
// - Page navigation
// - Zoom controls
// - Fullscreen mode
// - Better error handling
```

## Future Enhancements

- [ ] Text search functionality
- [ ] Annotation support
- [ ] Print functionality
- [ ] Custom themes
- [ ] Advanced zoom controls
- [ ] Thumbnail navigation 