/**
 * Resume list view card that we use to display the resume search results to the user on the 
 * frontend.
 */

import { View, StyleSheet, Pressable, Platform, Image, Modal, Dimensions, Text, TouchableOpacity } from 'react-native';
import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faDownload, faHeart, faExpand, faTimes, faChevronLeft, faChevronRight, faMinus, faPlus, faChevronUp, faChevronDown } from '@fortawesome/free-solid-svg-icons';

import Carousel from "./Carousel";
import LightTheme from '../../themes/LightTheme';
import PDFViewerComponent from '../PDFViewerComponent';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');
 
/**
 * @param {object} item
 * @param {string} item.key The URI.
 * @param {number} item.width
 * @param {number} item.height
 * @return {React.ReactElement}
 */
export default function ListViewCard({ item }) 
{
    const [saved, setSaved] = useState(false);
    const [liked, setLiked] = useState(false);
    const [showFullscreen, setShowFullscreen] = useState(false);
    const [currentPage, setCurrentPage] = useState(0);
    const [zoomLevel, setZoomLevel] = useState(1);
    const [imagePosition, setImagePosition] = useState({ x: 0, y: 0 });

    // Add specific CSS to disable tap highlights for fullscreen button
    useEffect(() => {
        if (Platform.OS === 'web') {
            const style = document.createElement('style');
            style.textContent = `
                .fullscreen-button {
                    -webkit-tap-highlight-color: transparent !important;
                    -webkit-touch-callout: none !important;
                    -webkit-user-select: none !important;
                    -moz-user-select: none !important;
                    -ms-user-select: none !important;
                    user-select: none !important;
                    outline: none !important;
                    border: none !important;
                    touch-action: manipulation !important;
                }
            `;
            document.head.appendChild(style);
            return () => document.head.removeChild(style);
        }
    }, []);

    // Add keyboard navigation when in fullscreen mode
    useEffect(() => {
        if (Platform.OS === 'web' && showFullscreen) {
            const handleKeyDown = (e) => {
                if (zoomLevel > 1) {
                    switch (e.key) {
                        case 'ArrowUp':
                            e.preventDefault();
                            setImagePosition(prev => ({
                                ...prev,
                                y: prev.y + 50
                            }));
                            break;
                        case 'ArrowDown':
                            e.preventDefault();
                            setImagePosition(prev => ({
                                ...prev,
                                y: prev.y - 50
                            }));
                            break;
                    }
                }
            };

            window.addEventListener('keydown', handleKeyDown);
            return () => window.removeEventListener('keydown', handleKeyDown);
        }
    }, [showFullscreen, zoomLevel]);

    const incrementDownloadCounter = async () => {
        try {
            console.log(process.env);
            const response = await fetch(process.env.EXPO_PUBLIC_ORIGIN+`v1/resume/${item.key}/increment-download`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error('Failed to increment download counter');
            }

            console.log('Download count incremented successfully');
        } catch (error) {
            console.error('Error incrementing download count:', error);
        }
    };

    const handleLike = () => {
        setLiked(!liked);
        // TODO: Add API call to save like status
        console.log('Like toggled:', !liked);
    };

    const downloadImage = async () => {
        setSaved(true);
        await incrementDownloadCounter();
        if(Platform.OS === 'web') {
            fetch(item.download_url)
                .then((response) => {
                    if (!response.ok) {
                        throw new Error('Response was invalid.');
                    }
                    return response.blob();
                })
                .then((fileBlob) => {
                    const dataUrl = window.URL.createObjectURL(fileBlob);
                    const a = document.createElement('a');
                    // Check if it's a PDF and set appropriate filename
                    const isPDF = item.download_url.toLowerCase().includes('.pdf') || 
                                 fileBlob.type === 'application/pdf';
                    a.download = isPDF ? 'resume.pdf' : 'Fresume';
                    a.href = dataUrl;
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                })
                .catch((error) => {
                    console.error('Error fetching the file:', error);
                });
        }
    };

    const openFullscreen = () => {
        console.log('Opening fullscreen with item:', item);
        console.log('Image URLs:', item.url[0]);
        console.log('Current page:', currentPage);
        console.log('Image URL for current page:', item.url[0][currentPage]);
        setShowFullscreen(true);
        setCurrentPage(0);
        setZoomLevel(1);
        setImagePosition({ x: 0, y: 0 });
    };

    const closeFullscreen = () => {
        setShowFullscreen(false);
    };

    const goToNextPage = () => {
        if (currentPage < item.url[0].length - 1) {
            setCurrentPage(currentPage + 1);
        }
    };

    const goToPreviousPage = () => {
        if (currentPage > 0) {
            setCurrentPage(currentPage - 1);
        }
    };

    const zoomOut = () => {
        if (zoomLevel > 0.5) {
            setZoomLevel(prevZoom => {
                const newZoom = prevZoom - 0.1;
                return Number(newZoom.toFixed(1));
            });
        }
    };

    const zoomIn = () => {
        if (zoomLevel < 3) {
            setZoomLevel(prevZoom => {
                const newZoom = prevZoom + 0.1;
                return Number(newZoom.toFixed(1));
            });
        }
    };

    const downloadFullscreen = async () => {
        setSaved(true);
        await incrementDownloadCounter();
        if(Platform.OS === 'web') {
            fetch(item.download_url)
                .then((response) => {
                    if (!response.ok) {
                        throw new Error('Response was invalid.');
                    }
                    return response.blob();
                })
                .then((fileBlob) => {
                    const dataUrl = window.URL.createObjectURL(fileBlob);
                    const a = document.createElement('a');
                    // Check if it's a PDF and set appropriate filename
                    const isPDF = item.download_url.toLowerCase().includes('.pdf') || 
                                 fileBlob.type === 'application/pdf';
                    a.download = isPDF ? 'resume.pdf' : 'Fresume';
                    a.href = dataUrl;
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                })
                .catch((error) => {
                    console.error('Error fetching the file:', error);
                });
        }
    };

    // Helper to check if the file is a PDF
    const isPDF = (url) => url && url.toLowerCase().endsWith('.pdf');

    // Get the correct PDF download URL for the viewer
    let pdfUrl = '';
    if (item.download_url) {
        pdfUrl = item.download_url;
    } else if (Array.isArray(item.url) && Array.isArray(item.url[0]) && item.url[0].length > 0) {
        pdfUrl = item.url[0][0];
        // Prepend /resumes/ if it's just a filename
        if (pdfUrl && !pdfUrl.startsWith('/') && !pdfUrl.startsWith('http')) {
            pdfUrl = `/resumes/${pdfUrl}`;
        }
    }
    // Debug log to check what URL is being passed to the PDF viewer
    console.log('ListViewCard pdfUrl:', pdfUrl, 'item:', item);
    // Force PDFViewerComponent to always render for debugging
    return (
        <View style={styles.cardContainer}>
            <PDFViewerComponent url={pdfUrl} width={item.width} height={item.height} />
            {/* Bottom Action Bar (like, download, etc.) */}
            <View style={styles.actionBar}>
                <Pressable 
                    style={styles.actionButton} 
                    onPress={handleLike}
                    android_ripple={null}
                    android_disableSound={true}
                >
                    <FontAwesomeIcon 
                        icon={faHeart} 
                        size={20} 
                        color={liked ? LightTheme.colors.red[500] : LightTheme.colors.grey[400]} 
                        style={styles.iconStyle}
                        focusable={false}
                    />
                </Pressable>
                <Pressable 
                    style={styles.actionButton} 
                    onPress={downloadImage}
                    android_ripple={null}
                    android_disableSound={true}
                >
                    <FontAwesomeIcon 
                        icon={faDownload} 
                        size={20} 
                        color={saved ? LightTheme.primary : LightTheme.colors.grey[400]} 
                        style={styles.iconStyle}
                        focusable={false}
                    />
                </Pressable>
            </View>
        </View>
    );
}

/**
 * Styles for the resume list header.
 */
const styles = StyleSheet.create({
    cardContainer: {
        backgroundColor: LightTheme.backgroundSecondary,
        marginBottom: 10,
        width: '100%',
        position: 'relative',
        borderRadius: 8,
        overflow: 'visible',
        borderStyle: 'solid',
        borderBottomWidth: 4,
        borderColor: LightTheme.text,
        height: 'auto',
        minHeight: 'auto',
        ...(Platform.OS === 'web' ? {
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
            maxWidth: 'none',
        } : {
            elevation: 2,
        }),
    },
    fullscreenButton: {
        position: 'absolute',
        top: 10,
        right: 10,
        backgroundColor: 'rgba(255, 255, 255, 0.8)',
        borderRadius: 20,
        width: 32,
        height: 32,
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 10,
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outlineStyle: 'none',
            borderStyle: 'none',
            touchAction: 'manipulation',
            userSelect: 'none',
            msUserSelect: 'none',
            MozUserSelect: 'none',
        } : {}),
    },
    actionBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 15,
        paddingVertical: 10,
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderTopWidth: 1,
        borderTopColor: LightTheme.colors.grey[200],
    },
    actionButton: {
        padding: 8,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.8)',
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            WebkitAppearance: 'none',
            WebkitBorderRadius: '20px',
            outline: 'none',
            border: 'none',
            touchAction: 'manipulation',
            userSelect: 'none',
            msUserSelect: 'none',
            MozUserSelect: 'none',
            WebkitFocusRingColor: 'transparent',
            WebkitBoxShadow: 'none',
            boxShadow: 'none',
            ':hover': {
                backgroundColor: 'rgba(255, 255, 255, 1)',
                transform: 'scale(1.1)',
            },
            ':active': {
                backgroundColor: 'rgba(240, 240, 240, 1)',
                WebkitTapHighlightColor: 'transparent',
            },
        } : {}),
    },
    fullscreenOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.9)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    headerBar: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        zIndex: 1000,
        ...(Platform.OS === 'web' ? {
            backdropFilter: 'blur(10px)',
            WebkitBackdropFilter: 'blur(10px)',
        } : {}),
    },
    pageInfo: {
        flex: 1,
        alignItems: 'flex-start',
    },
    pageInfoText: {
        color: LightTheme.colors.white,
        fontSize: 14,
        fontWeight: '500',
    },
    zoomControls: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
    },
    zoomButton: {
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: 5,
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
            border: 'none',
            touchAction: 'manipulation',
            ':hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.3)',
            },
            ':active': {
                backgroundColor: 'rgba(255, 255, 255, 0.4)',
            }
        } : {}),
    },
    zoomText: {
        color: LightTheme.colors.white,
        fontSize: 14,
        fontWeight: '600',
        marginHorizontal: 15,
        minWidth: 50,
        textAlign: 'center',
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            userSelect: 'none',
        } : {}),
    },
    actions: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        flex: 1,
    },
    actionButtonFullscreen: {
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 10,
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
            border: 'none',
            touchAction: 'manipulation',
            ':hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
            },
        } : {}),
    },
    closeButton: {
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
            border: 'none',
            touchAction: 'manipulation',
            ':hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
            },
        } : {}),
    },
    documentContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'relative',
        paddingTop: 80, // Space for header
    },
    navButton: {
        position: 'absolute',
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000,
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            outline: 'none',
            border: 'none',
            touchAction: 'manipulation',
            transition: 'all 0.2s ease-in-out',
            ':hover': {
                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                transform: [{ translateX: -20 }, { scale: 1.1 }],
            },
        } : {}),
    },
    prevButton: {
        left: 20,
    },
    nextButton: {
        right: 20,
    },
    imageContainer: {
        flex: 1,
        width: '100%',
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        backgroundColor: 'transparent',
        position: 'relative',
        ...(Platform.OS === 'web' ? {
            transition: 'transform 0.3s ease-out',
            overflowY: 'hidden',
            overflowX: 'hidden',
            WebkitOverflowScrolling: 'touch'
        } : {}),
    },
    imageFallback: {
        position: 'absolute',
        top: 10,
        left: 10,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        padding: 10,
        borderRadius: 5,
        zIndex: 1000,
    },
    imageFallbackText: {
        color: LightTheme.colors.white,
        fontSize: 12,
        fontFamily: 'monospace',
    },
    iconStyle: {
        ...(Platform.OS === 'web' ? {
            WebkitTapHighlightColor: 'transparent',
            WebkitUserSelect: 'none',
            WebkitTouchCallout: 'none',
            WebkitAppearance: 'none',
            outline: 'none',
            border: 'none',
            touchAction: 'manipulation',
            userSelect: 'none',
            msUserSelect: 'none',
            MozUserSelect: 'none',
            WebkitFocusRingColor: 'transparent',
            WebkitBoxShadow: 'none',
            boxShadow: 'none',
            pointerEvents: 'none',
        } : {}),
    },
});
