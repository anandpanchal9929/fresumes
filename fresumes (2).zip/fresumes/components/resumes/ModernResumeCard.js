import React from 'react';
import { View, Text, Image, StyleSheet, Pressable, Platform } from 'react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faStar, faBookmark, faEllipsisH } from '@fortawesome/free-solid-svg-icons';
import ModernTheme from '../../themes/ModernTheme';

const ModernResumeCard = ({ resume, onPress }) => {
    return (
        <Pressable 
            style={styles.container}
            onPress={() => onPress && onPress(resume)}
            {...(Platform.OS === 'web' ? {
                onMouseEnter: () => {},
                onMouseLeave: () => {},
            } : {})}
        >
            <View style={styles.imageContainer}>
                <Image
                    source={{ uri: resume.image }}
                    style={styles.image}
                    resizeMode="cover"
                />
                <View style={styles.overlay}>
                    <View style={styles.actions}>
                        <Pressable style={styles.actionButton}>
                            <FontAwesomeIcon 
                                icon={faStar} 
                                size={16} 
                                color={ModernTheme.colors.white}
                                focusable={false}
                            />
                        </Pressable>
                        <Pressable style={styles.actionButton}>
                            <FontAwesomeIcon 
                                icon={faBookmark} 
                                size={16} 
                                color={ModernTheme.colors.white}
                                focusable={false}
                            />
                        </Pressable>
                        <Pressable style={styles.actionButton}>
                            <FontAwesomeIcon 
                                icon={faEllipsisH} 
                                size={16} 
                                color={ModernTheme.colors.white}
                                focusable={false}
                            />
                        </Pressable>
                    </View>
                </View>
            </View>
            <View style={styles.content}>
                <Text style={styles.title} numberOfLines={2}>{resume.title}</Text>
                <Text style={styles.description} numberOfLines={3}>{resume.description}</Text>
                <View style={styles.meta}>
                    <Text style={styles.metaText}>{resume.experience}</Text>
                    <Text style={styles.metaText}>{resume.education}</Text>
                    <Text style={styles.metaText}>{resume.datePosted}</Text>
                </View>
            </View>
        </Pressable>
    );
};

const styles = StyleSheet.create({
    container: {
        backgroundColor: ModernTheme.colors.white,
        borderRadius: ModernTheme.borderRadius.lg,
        overflow: 'hidden',
        marginBottom: ModernTheme.spacing.md,
        borderWidth: 1,
        borderColor: ModernTheme.colors.grey[200],
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            transition: 'transform 0.2s ease-in-out',
            ':hover': {
                transform: 'translateY(-2px)',
            },
        } : {}),
    },
    imageContainer: {
        position: 'relative',
        width: '100%',
        height: 200,
    },
    image: {
        width: '100%',
        height: '100%',
    },
    overlay: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        opacity: 0,
        ...(Platform.OS === 'web' ? {
            transition: 'opacity 0.2s ease-in-out',
            ':hover': {
                opacity: 1,
            },
        } : {}),
    },
    actions: {
        position: 'absolute',
        top: ModernTheme.spacing.md,
        right: ModernTheme.spacing.md,
        flexDirection: 'row',
        gap: ModernTheme.spacing.sm,
    },
    actionButton: {
        width: 32,
        height: 32,
        borderRadius: ModernTheme.borderRadius.full,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
        ...(Platform.OS === 'web' ? {
            cursor: 'pointer',
            transition: 'background-color 0.2s ease-in-out',
            ':hover': {
                backgroundColor: 'rgba(0, 0, 0, 0.7)',
            },
        } : {}),
    },
    content: {
        padding: ModernTheme.spacing.md,
    },
    title: {
        fontSize: ModernTheme.typography.fontSize.lg,
        fontWeight: '600',
        color: ModernTheme.colors.text.primary,
        marginBottom: ModernTheme.spacing.sm,
    },
    description: {
        fontSize: ModernTheme.typography.fontSize.sm,
        color: ModernTheme.colors.text.secondary,
        marginBottom: ModernTheme.spacing.md,
        lineHeight: 20,
    },
    meta: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: ModernTheme.spacing.sm,
    },
    metaText: {
        fontSize: ModernTheme.typography.fontSize.xs,
        color: ModernTheme.colors.grey[500],
        backgroundColor: ModernTheme.colors.grey[100],
        paddingHorizontal: ModernTheme.spacing.sm,
        paddingVertical: ModernTheme.spacing.xs,
        borderRadius: ModernTheme.borderRadius.full,
    },
});

export default ModernResumeCard; 