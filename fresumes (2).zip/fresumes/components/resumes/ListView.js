/**
 * This components creates the list view for the resume. Specifcially it is in charge of displaying the resumes that we 
 * load up from the server.
 */

import React, { useState, useCallback } from 'react';
import { Dimensions, StyleSheet, View, Platform } from 'react-native';
import Constants from 'expo-constants';
import LightTheme from '../../themes/LightTheme';
import InfiniteFlatList from '../InfiniteFlatList';
import ListViewCard from './ListViewCard';
import FresumesSearchBar from '../common/FresumesSearchBar';
import FresumesFiltersSidebar from '../common/FresumesFiltersSidebar';
import { findAll } from '../../infastructure/ResumeRepository';

const dimensions = Dimensions.get('window');

export default function ListView({}) {
    const [query, setQuery] = useState({});
    const [sidebarOpen, setSidebarOpen] = useState(false);

    const resumeSearch = useCallback((page_number) => {
        return findAll(query, page_number);
    }, [query]);

    // Top bar filter/search change
    const handleTopBarFilterChange = (filters) => {
        setQuery(prev => ({ ...prev, ...filters }));
    };

    // Sidebar filter change
    const handleSidebarFilterChange = (filters) => {
        setQuery(prev => ({ ...prev, ...filters }));
    };

    return (
        <View style={styles.bodyContainer}>
            <FresumesSearchBar
                onSearch={text => {
                    setQuery(prev => ({ ...prev, text }));
                }}
                onFilterChange={handleTopBarFilterChange}
                onTabClick={tab => { if (tab === 'All filters') setSidebarOpen(true); }}
                selectedTab={null}
            />
            {sidebarOpen && (
                <FresumesFiltersSidebar
                    onClose={() => setSidebarOpen(false)}
                    onFilterChange={handleSidebarFilterChange}
                />
            )}
            <InfiniteFlatList style={styles.listContainer} searchCallback={resumeSearch} ListItem={ListViewCard} />
        </View>
    );
}

const styles = StyleSheet.create({
    bodyContainer: {
        flex: 1,
        width: '100%',
        backgroundColor: LightTheme.background,
        marginTop: Constants.statusBarHeight,
        ...(Platform.OS === 'web' ? {
            scrollbarWidth: 'none',
            msOverflowStyle: 'none',
            WebkitScrollbar: {
                display: 'none'
            },
            overflowX: 'hidden',
            minHeight: '100vh',
        } : {})
    },
    listContainer: {
        zIndex: 100,
        width: dimensions.width >= 1000 ? '40%' : '100%',
        margin: 'auto',
        paddingHorizontal: dimensions.width < 768 ? 10 : 0,
        ...(Platform.OS === 'web' ? {
            overflowY: 'auto',
            overflowX: 'hidden',
            minHeight: '100vh',
        } : {})
    }
});
