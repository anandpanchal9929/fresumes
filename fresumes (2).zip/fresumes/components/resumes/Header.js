/**
 * The resume list header provides the user with a search bar and a filter dropdown.
 */

import React, { useState } from 'react';
import { View, Platform } from 'react-native';
import FresumesSearchBar from '../common/FresumesSearchBar';
import FresumesFiltersSidebar from '../common/FresumesFiltersSidebar';

export default function Header({ query, setQuery }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState('Posts');

  const handleTabClick = (tab) => {
    setSelectedTab(tab);
    if (tab === 'All filters') setSidebarOpen(true);
  };

  const handleSearch = (text) => {
    setQuery({ ...query, text });
  };

  const handleFilterChange = (filters) => {
    setQuery({ ...query, ...filters });
  };

  return (
    <View style={{ position: 'relative', zIndex: 200 }}>
      <FresumesSearchBar
        onTabClick={handleTabClick}
        onSearch={handleSearch}
        onFilterChange={handleFilterChange}
        selectedTab={selectedTab}
      />
      {sidebarOpen && (
        <FresumesFiltersSidebar onClose={() => setSidebarOpen(false)} onFilterChange={handleFilterChange} />
      )}
    </View>
  );
}