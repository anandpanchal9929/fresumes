/**
 * PDF Viewer component for displaying PDF files in the app.
 */

import React, { useState } from 'react';
import { Worker, Viewer } from '@react-pdf-viewer/core';
import '@react-pdf-viewer/core/lib/styles/index.css';
import './PDFViewerStyles.css';

export default function PDFViewer({ url, width = '100%' }) {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  // Debug: log the url prop
  console.log('PDFViewer url:', url);



  if (!url) {
    return <div style={{ color: 'red', padding: 16 }}>No PDF URL provided.</div>;
    }

    return (
    <div
      className="pdf-viewer-container"
      style={{
        width: '100%',
        minWidth: 0,
        maxWidth: '100%',
        background: '#fff',
        padding: '0',
        margin: 0,
        borderRadius: 0,
        boxShadow: 'none',
        overflowY: 'auto',
        overflowX: 'hidden',
        display: 'block',
      }}
    >
      {error ? (
        <div style={{ color: 'red', padding: 16 }}>Failed to load PDF. Please check the file path and try again.<br/>URL: {url}</div>
      ) : (
        <Worker workerUrl="https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js">
          <div style={{ width: '100%', minWidth: 0, margin: 0, padding: '0 0 32px 0', overflow: 'hidden', display: 'block', maxWidth: '100%', marginLeft: 'auto', marginRight: 'auto' }}>
            <Viewer
              fileUrl={url}
              defaultScale={1.0}
              theme="light"
              onDocumentLoad={() => setLoading(false)}
              onDocumentLoadFail={() => { setError(true); setLoading(false); }}
            />
            {loading && (
              <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', padding: 16 }}>
                <div className="pdf-loading-spinner" style={{ width: 32, height: 32, border: '4px solid #eee', borderTop: '4px solid #1976d2', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
                <style>{`
                  @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                  }
                `}</style>
              </div>
            )}
          </div>
        </Worker>
      )}
    </div>
  );
}
