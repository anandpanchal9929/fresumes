import EmptyInfiniteList from './EmptyInfiniteList';
import InfiniteListFooter from './InfiniteListFooter';
import { ActivityIndicator, FlatList, ScrollView, StyleSheet, View } from 'react-native';
import React, { useState, useEffect } from 'react';
import LightTheme from '../themes/LightTheme';

export default function InfiniteFlatList({ style, searchCallback, ListItem }) {
    const [endOfData, setEndOfData] = useState(false);
    const [searching, setSearching] = useState(false);
    const [page, setPage] = useState(0);
    const [data, setData] = useState([]);

    const fetchNextPage = async () => {
        const nextPage = page + 1;
        if (endOfData) return;

        const newData = await searchCallback(nextPage);
        if (newData.length === 0) setEndOfData(true);

        setData([...data, ...newData]);
        setPage(nextPage);
    };

    useEffect(() => {
        const searchWithNewQuery = async () => {
            const data = await searchCallback(0);
            setSearching(false);
            setData(data);
        };

        setEndOfData(false);
        setPage(0);
        setSearching(true);

        searchWithNewQuery();
    }, [searchCallback]);

    if (searching) {
        return (
            <View style={styles.activityIndicatorContainer}>
                <ActivityIndicator size="large" color={LightTheme.primary} />
            </View>
        );
    }

    return (
        <ScrollView contentContainerStyle={styles.scrollViewContainer}>
            <FlatList
                ListEmptyComponent={<EmptyInfiniteList />}
                ListFooterComponent={<InfiniteListFooter />}
                ListFooterComponentStyle={styles.footerItem}
                contentContainerStyle={{ flexGrow: 1 }}
                onEndReached={fetchNextPage}
                onEndReachedThreshold={2}
                data={data}
                renderItem={({ item }) => <ListItem key={item.key} item={item} />}
                style={StyleSheet.flatten([styles.flatListContainer, style])}
            />
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    activityIndicatorContainer: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    flatListContainer: {
        flexGrow: 1, // Allow the FlatList to expand
    },
    scrollViewContainer: {
        flexGrow: 1,
        paddingHorizontal: 0,
    },
    footerItem: {
        height: 50,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
});