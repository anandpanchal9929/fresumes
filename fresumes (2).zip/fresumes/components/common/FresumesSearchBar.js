import React, { useState, useRef } from "react";
import { View, TextInput, Image, StyleSheet, ScrollView, Pressable, Text, Platform, FlatList } from "react-native";

const FILTER_TABS = [
  "Sort By", "Experience", "Language", "All filters", "Clear"
];

const API_BASE_URL = process.env.EXPO_PUBLIC_API_ORIGIN || 'http://localhost/v1';

async function fetchSuggestions(query) {
  if (!query || query.length < 2) return [];
  try {
    const response = await fetch(`${API_BASE_URL}/suggestions?q=${encodeURIComponent(query)}`);
    const data = await response.json();
    return data.suggestions || [];
  } catch (error) {
    return [];
  }
}

// Helper function to parse natural language search queries
function parseNaturalLanguage(query) {
  const filters = {};
  const lowerQuery = query.toLowerCase();
  
  // Simple parsing logic - can be enhanced based on requirements
  if (lowerQuery.includes('entry') || lowerQuery.includes('junior')) {
    filters.experience = 'Entry Level';
  } else if (lowerQuery.includes('senior') || lowerQuery.includes('5+')) {
    filters.experience = '5+ years';
  } else if (lowerQuery.includes('1-3') || lowerQuery.includes('1 to 3')) {
    filters.experience = '1-3 years';
  } else if (lowerQuery.includes('3-5') || lowerQuery.includes('3 to 5')) {
    filters.experience = '3-5 years';
  }
  
  // Language detection
  const languages = ['english', 'hindi', 'russian', 'spanish', 'mandarin', 'french', 'arabic', 'bengali', 'portuguese'];
  for (const lang of languages) {
    if (lowerQuery.includes(lang)) {
      filters.language = lang.charAt(0).toUpperCase() + lang.slice(1);
      break;
    }
  }
  
  return filters;
}

export default function FresumesSearchBar({ onTabClick, onSearch, onFilterChange, selectedTab }) {
  const [searchText, setSearchText] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [recentSearches, setRecentSearches] = useState([]);
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [selectedSort, setSelectedSort] = useState("Most relevant");
  const [sortBtnLayout, setSortBtnLayout] = useState(null);
  const [showExperienceDropdown, setShowExperienceDropdown] = useState(false);
  const [selectedExperience, setSelectedExperience] = useState(null);
  const [experienceBtnLayout, setExperienceBtnLayout] = useState(null);
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const [languageBtnLayout, setLanguageBtnLayout] = useState(null);
  const [searchInputLayout, setSearchInputLayout] = useState(null);
  const inputRef = useRef();
  const sortBtnRef = useRef();
  const experienceBtnRef = useRef();
  const languageBtnRef = useRef();

  const SORT_OPTIONS = [
    "Most relevant",
    "Most recent",
    "Most viewed",
    "Most Downloaded"
  ];

  const EXPERIENCE_OPTIONS = [
    "Entry Level",
    "1-3 years",
    "3-5 years",
    "5+ years"
  ];

  const LANGUAGE_OPTIONS = [
    "English", "Hindi", "Russian", "Spanish", "Mandarin Chinese", "French", "Arabic", "Bengali", "Portuguese"
  ];

  const [suggestions, setSuggestions] = useState([]);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  // Unified filter state
  const [filterState, setFilterState] = useState({
    sortBy: "Most relevant",
    experience: null,
    language: null,
    text: ""
  });

  // Helper to trigger filter change
  const triggerFilterChange = (newState) => {
    setFilterState(newState);
    if (onFilterChange) {
      // Map UI state to backend query params
      const query = {
        sortBy: newState.sortBy === "Most relevant" ? undefined : newState.sortBy?.toLowerCase().replace("most ", ""),
        experience: newState.experience,
        language: newState.language,
        text: newState.text
      };
      onFilterChange(query);
    }
  };

  // Update filter state on any change
  const handleSortChange = (option) => {
    triggerFilterChange({ ...filterState, sortBy: option });
  };
  const handleExperienceChange = (option) => {
    triggerFilterChange({ ...filterState, experience: option });
  };
  const handleLanguageChange = (option) => {
    triggerFilterChange({ ...filterState, language: option });
  };
  const handleSearchChange = (text) => {
    setSearchText(text);
    setShowSuggestions(true);
    triggerFilterChange({ ...filterState, text });
  };

  React.useEffect(() => {
    if (searchText.length > 1) {
      setIsLoadingSuggestions(true);
      fetchSuggestions(searchText).then(suggestions => {
        setSuggestions(suggestions);
        setIsLoadingSuggestions(false);
      });
    } else {
      setSuggestions([]);
    }
  }, [searchText]);

  // Helper to close dropdown when clicking outside
  const renderSortDropdown = () => {
    if (!showSortDropdown || !sortBtnLayout) return null;
    return (
      <>
        <Pressable style={styles.dropdownOverlay} onPress={() => setShowSortDropdown(false)} />
        <View style={[styles.dropdownMenu, {
          position: 'absolute',
          top: sortBtnLayout.pageY + sortBtnLayout.height,
          left: sortBtnLayout.pageX,
        }]}
        >
          <Text style={styles.dropdownTitle}>Sort By</Text>
          {SORT_OPTIONS.map(option => (
            <Pressable
              key={option}
              style={styles.dropdownItem}
              onPress={() => {
                setSelectedSort(option);
                setShowSortDropdown(false);
                handleSortChange(option);
              }}
            >
              <View style={styles.checkboxContainer}>
                <View style={[styles.checkbox, selectedSort === option && styles.checkboxChecked]}>
                  {selectedSort === option && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.dropdownItemText}>{option}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      </>
    );
  };
  const renderExperienceDropdown = () => {
    if (!showExperienceDropdown || !experienceBtnLayout) return null;
    return (
      <>
        <Pressable style={styles.dropdownOverlay} onPress={() => setShowExperienceDropdown(false)} />
        <View style={[styles.dropdownMenu, {
          position: 'absolute',
          top: experienceBtnLayout.pageY + experienceBtnLayout.height,
          left: experienceBtnLayout.pageX,
        }]}
        >
          <Text style={styles.dropdownTitle}>Experience Level</Text>
          {EXPERIENCE_OPTIONS.map(option => (
            <Pressable
              key={option}
              style={styles.dropdownItem}
              onPress={() => {
                setSelectedExperience(option);
                setShowExperienceDropdown(false);
                handleExperienceChange(option);
              }}
            >
              <View style={styles.checkboxContainer}>
                <View style={[styles.checkbox, selectedExperience === option && styles.checkboxChecked]}>
                  {selectedExperience === option && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.dropdownItemText}>{option}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      </>
    );
  };
  const renderLanguageDropdown = () => {
    if (!showLanguageDropdown || !languageBtnLayout) return null;
    return (
      <>
        <Pressable style={styles.dropdownOverlay} onPress={() => setShowLanguageDropdown(false)} />
        <View style={[styles.dropdownMenu, {
          position: 'absolute',
          top: languageBtnLayout.pageY + languageBtnLayout.height,
          left: languageBtnLayout.pageX,
        }]}
        >
          <Text style={styles.dropdownTitle}>Language</Text>
          {LANGUAGE_OPTIONS.map(option => (
            <Pressable
              key={option}
              style={styles.dropdownItem}
              onPress={() => {
                setSelectedLanguage(option);
                setShowLanguageDropdown(false);
                handleLanguageChange(option);
              }}
            >
              <View style={styles.checkboxContainer}>
                <View style={[styles.checkbox, selectedLanguage === option && styles.checkboxChecked]}>
                  {selectedLanguage === option && <Text style={styles.checkboxTick}>✓</Text>}
                </View>
                <Text style={styles.dropdownItemText}>{option}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      </>
    );
  };

  // Helper to get the display name for each filter tab
  const getTabDisplayName = (tab) => {
    if (tab === "Sort By") {
      return selectedSort === "Most relevant" ? "Sort By" : `Sort By - ${selectedSort}`;
    }
    if (tab === "Experience") {
      return selectedExperience ? `Experience - ${selectedExperience}` : "Experience";
    }
    if (tab === "Language") {
      return selectedLanguage ? `Language - ${selectedLanguage}` : "Language";
    }
    // Add similar logic for Language if you add state for it
    return tab;
  };

  const isTabActive = (tab) => {
    if (tab === "Sort By") return selectedSort !== "Most relevant";
    if (tab === "Experience") return selectedExperience !== null;
    if (tab === "Language") return selectedLanguage !== null;
    return false;
  };

  const filteredSuggestions = suggestions;

  const handleSuggestionClick = (suggestion) => {
    setSearchText(suggestion.label);
    setShowSuggestions(false);
    if (onSearch) onSearch(suggestion.label);
    setRecentSearches([suggestion.label, ...recentSearches.filter(s => s !== suggestion.label)].slice(0, 5));
    // Simulate filter update
    if (onFilterChange) {
      const filters = parseNaturalLanguage(suggestion.label);
      if (Object.keys(filters).length > 0) onFilterChange(filters);
    }
  };

  const handleRecentClick = (recent) => {
    setSearchText(recent);
    setShowSuggestions(false);
    if (onSearch) onSearch(recent);
    // Simulate filter update
    if (onFilterChange) {
      const filters = parseNaturalLanguage(recent);
      if (Object.keys(filters).length > 0) onFilterChange(filters);
    }
  };

  // Render suggestions as a separate overlay
  const renderSuggestions = () => {
    if (!showSuggestions || !searchInputLayout || (filteredSuggestions.length === 0 && recentSearches.length === 0)) {
      return null;
    }

    return (
      <>
        <Pressable 
          style={styles.suggestionsOverlay} 
          onPress={() => setShowSuggestions(false)}
        />
        <View style={[styles.suggestionsDropdown, {
          position: 'absolute',
          top: searchInputLayout.pageY + searchInputLayout.height + 4,
          left: searchInputLayout.pageX + (searchInputLayout.width * 0.1),
          width: searchInputLayout.width * 0.8,
          marginLeft: 0,
          paddingLeft: 0,
        }]}>
          {filteredSuggestions.length > 0 && (
            <View>
              {filteredSuggestions.map((s, i) => (
                <Pressable 
                  key={s.label + i} 
                  style={styles.suggestionItem} 
                  onPress={() => handleSuggestionClick(s)}
                >
                  <Text style={styles.suggestionText}>{s.label}</Text>
                  <Text style={styles.suggestionType}>{s.type}</Text>
                </Pressable>
              ))}
            </View>
          )}
          {recentSearches.length > 0 && (
            <View style={styles.recentSection}>
              <Text style={styles.recentTitle}>Recent</Text>
              {recentSearches.map((r, i) => (
                <Pressable 
                  key={r + i} 
                  style={styles.suggestionItem} 
                  onPress={() => handleRecentClick(r)}
                >
                  <Text style={styles.suggestionText}>{r}</Text>
                </Pressable>
              ))}
            </View>
          )}
        </View>
      </>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.searchRow}>
       <a href="/" style={{ display: 'flex' , alignItems: 'center' }}>
	<Image source={require('../../assets/logo.png')} style={styles.logo} />
	</a>
        <View style={{ flex: 1, position: 'relative' }}>
          <TextInput
            ref={inputRef}
            style={styles.searchInput}
            placeholder="Search Resumes"
            placeholderTextColor="#666"
            value={searchText}
            onChangeText={handleSearchChange}
            onFocus={() => setShowSuggestions(true)}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
            onLayout={(e) => {
              const { x, y, width, height } = e.nativeEvent.layout;
              setSearchInputLayout({ width, height, pageX: x, pageY: y });
            }}
          />
        </View>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsRow}>
        {FILTER_TABS.map((tab, i) => (
          <View key={tab} style={{ position: 'relative' }}>
          <Pressable
              ref={
                tab === "Sort By" ? sortBtnRef :
                tab === "Experience" ? experienceBtnRef :
                tab === "Language" ? languageBtnRef : undefined
              }
              style={[
                styles.tabBtn,
                isTabActive(tab) && styles.activeTabBtn,
                tab === "All filters" && styles.allFiltersBtn,
                selectedTab === tab && styles.selectedTab
              ]}
              onPress={() => {
                if (tab === "Clear") {
                  setSearchText("");
                  setShowSortDropdown(false);
                  setShowExperienceDropdown(false);
                  setShowLanguageDropdown(false);
                  setSelectedSort("Most relevant"); // Reset 'Short by' to default
                  setSelectedExperience(null); // Reset 'Experience' to default
                  setSelectedLanguage(null); // Reset 'Language' to default
                  if (onFilterChange) onFilterChange({});
                  if (onTabClick) onTabClick(tab);
                } else if (tab === "Sort By") {
                  setShowExperienceDropdown(false);
                  setShowLanguageDropdown(false);
                  if (!showSortDropdown && sortBtnRef.current) {
                    sortBtnRef.current.measure((fx, fy, width, height, px, py) => {
                      setSortBtnLayout({ width, height, pageX: px, pageY: py });
                      setShowSortDropdown(true);
                    });
                  } else {
                    setShowSortDropdown(false);
                  }
                } else if (tab === "Experience") {
                  setShowSortDropdown(false);
                  setShowLanguageDropdown(false);
                  if (!showExperienceDropdown && experienceBtnRef.current) {
                    experienceBtnRef.current.measure((fx, fy, width, height, px, py) => {
                      setExperienceBtnLayout({ width, height, pageX: px, pageY: py });
                      setShowExperienceDropdown(true);
                    });
                  } else {
                    setShowExperienceDropdown(false);
                  }
                } else if (tab === "Language") {
                  setShowSortDropdown(false);
                  setShowExperienceDropdown(false);
                  if (!showLanguageDropdown && languageBtnRef.current) {
                    languageBtnRef.current.measure((fx, fy, width, height, px, py) => {
                      setLanguageBtnLayout({ width, height, pageX: px, pageY: py });
                      setShowLanguageDropdown(true);
                    });
                  } else {
                    setShowLanguageDropdown(false);
                  }
                } else {
                  setShowSortDropdown(false);
                  setShowExperienceDropdown(false);
                  setShowLanguageDropdown(false);
                  if (onTabClick) onTabClick(tab);
                }
              }}
              onLayout={(e) => {
                if (tab === "Sort By") {
                  if (!sortBtnRef.current) {
                    const { x, y, width, height } = e.nativeEvent.layout;
                    setSortBtnLayout({ width, height, pageX: x, pageY: y });
                  }
                } else if (tab === "Experience") {
                   if (!experienceBtnRef.current) {
                    const { x, y, width, height } = e.nativeEvent.layout;
                    setExperienceBtnLayout({ width, height, pageX: x, pageY: y });
                  }
                } else if (tab === "Language") {
                  if (!languageBtnRef.current) {
                    const { x, y, width, height } = e.nativeEvent.layout;
                    setLanguageBtnLayout({ width, height, pageX: x, pageY: y });
                  }
                }
              }}
            >
              <Text style={styles.tabText}>{getTabDisplayName(tab)}</Text>
          </Pressable>
          </View>
        ))}
      </ScrollView>
      {renderSortDropdown()}
      {renderExperienceDropdown()}
      {renderLanguageDropdown()}
      {renderSuggestions()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 10,
    boxShadow: Platform.OS === 'web' ? '0 2px 8px rgba(0,0,0,0.04)' : undefined,
    zIndex: 10,
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  logo: {
    width: 36,
    height: 36,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    fontSize: 16,
    backgroundColor: '#f3f6f8',
    color: '#222',
  },
  suggestionsDropdown: {
    position: 'absolute',
    backgroundColor: '#fff',
    borderRadius: 8,
    boxShadow: Platform.OS === 'web' ? '0 4px 16px rgba(0,0,0,0.10)' : undefined,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    zIndex: 3000,
    paddingVertical: 4,
    paddingHorizontal: 0,
    maxHeight: 220,
    marginTop: 0,
    marginLeft: 0,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  suggestionText: {
    fontSize: 15,
    color: '#222',
  },
  suggestionType: {
    fontSize: 12,
    color: '#888',
    marginLeft: 8,
  },
  recentSection: {
    marginTop: 6,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 4,
  },
  recentTitle: {
    fontSize: 13,
    color: '#888',
    marginLeft: 12,
    marginBottom: 2,
  },
  tabsRow: {
    flexDirection: 'row',
    marginTop: 2,
  },
  tabBtn: {
    backgroundColor: '#f3f6f8',
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 18,
    marginRight: 8,
    marginBottom: 2,
    borderWidth: 1,
    borderColor: '#e0e0e0',
  },
  allFiltersBtn: {
    borderWidth: 1,
    borderColor: '#bdbdbd',
    fontWeight: '500',
  },
  selectedTab: {
    backgroundColor: '#e0e0e0',
    borderColor: '#d0d0d0',
  },
  activeTabBtn: {
    backgroundColor: '#FF1149', // Themed active color (light pink)
    borderColor: '#FF1149', // Themed active border color (dark pink)
    borderWidth: 1,
  },
  tabText: {
    fontSize: 15,
    color: '#222',
  },
  dropdownMenu: {
    position: 'absolute',
    top: 40,
    left: 0,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    zIndex: 2001,
    minWidth: 180,
    paddingVertical: 8,
    paddingHorizontal: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  dropdownOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2000,
    backgroundColor: 'transparent',
  },
  dropdownTitle: {
    fontWeight: 'bold',
    fontSize: 15,
    marginBottom: 8,
    marginLeft: 16,
    color: '#222',
  },
  dropdownItem: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: 18,
    height: 18,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#bdbdbd',
    marginRight: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  checkboxChecked: {
    backgroundColor: '#FF1149', // dark pink
    borderColor: '#FF1149',
  },
  checkboxTick: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
    lineHeight: 16,
  },
  dropdownItemText: {
    fontSize: 15,
    color: '#222',
  },
  suggestionsOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2999,
    backgroundColor: 'transparent',
  },
});
