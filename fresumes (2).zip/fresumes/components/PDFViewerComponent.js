/**
 * PDF Viewer component for displaying PDF files in the app.
 */

import React, { useState } from 'react';
import { Worker, Viewer } from '@react-pdf-viewer/core';
import '@react-pdf-viewer/core/lib/styles/index.css';
import './PDFViewerStyles.css';

export default function PDFViewerComponent({ url, width = '100%', height = 'auto' }) {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [pdfHeight, setPdfHeight] = useState('auto');

  // Add responsive CSS for mobile devices and fit PDF to card width
  React.useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      /* Make PDF fit inside card width without horizontal scrolling */
      .rpv-core__page-layer {
        max-width: 100% !important;
        overflow-x: hidden !important;
        overflow-y: auto !important;
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      .rpv-core__page-layer::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
      .rpv-core__page {
        max-width: 100% !important;
        width: 100% !important;
        overflow: hidden !important;
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      .rpv-core__page-canvas {
        max-width: 100% !important;
        width: 100% !important;
        height: auto !important;
        object-fit: contain !important;
      }
      /* Make viewer container fit card width */
      .rpv-core__viewer {
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
        overflow-x: hidden !important;
        overflow-y: auto !important;
        max-width: 100% !important;
        width: 100% !important;
      }
      .rpv-core__viewer::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
      /* Ensure all PDF elements fit within container */
      .rpv-core__page-layer * {
        max-width: 100% !important;
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      .rpv-core__page-layer *::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
      /* Global scrollbar hiding for any dynamically added elements */
      [class*="rpv-"] {
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
        max-width: 100% !important;
      }
      [class*="rpv-"]::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
      /* Force hide scrollbars on any element with overflow */
      * {
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      *::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  // Get responsive scale to fit PDF within card width
  const getResponsiveScale = () => {
    if (typeof window !== 'undefined') {
      const screenWidth = window.innerWidth;
      const cardWidth = typeof width === 'number' ? width : 400; // Default card width
      
      // Calculate scale to fit PDF within card width
      // PDF pages are typically 595x842 points (8.5" x 11")
      const pdfAspectRatio = 595 / 842;
      const maxScale = Math.min(1.0, cardWidth / 595);
      
      if (screenWidth < 480) return Math.min(0.7, maxScale); // Small phones
      if (screenWidth < 768) return Math.min(0.8, maxScale); // Medium phones
      if (screenWidth < 1024) return Math.min(0.9, maxScale); // Tablets
      return maxScale; // Desktop
    }
    return 0.8; // Default scale
  };

  if (!url) {
    return <div style={{ color: 'red', padding: 16 }}>No PDF URL provided.</div>;
  }

        return (
    <div
      className="pdf-viewer-container"
      style={{
        width: '100%',
        height: 'auto',
        minWidth: 0,
        maxWidth: '100%',
        background: '#fff',
        padding: '0',
        margin: 0,
        borderRadius: 0,
        boxShadow: 'none',
        overflow: 'hidden',
        display: 'block',
        scrollbarWidth: 'none',
        msOverflowStyle: 'none',
      }}
    >
      {error ? (
        <div style={{ color: 'red', padding: 16 }}>
          Failed to load PDF. Please check the file path and try again.<br/>URL: {url}
          <br/>
          <span style={{ color: '#888', fontSize: 12 }}>If you are using an uncommon browser, try Chrome or Firefox.</span>
        </div>
      ) : (
        <Worker workerUrl="https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js">
          <div style={{ 
            width: '100%', 
            minWidth: 0, 
            margin: 0, 
            padding: '0', 
            overflow: 'hidden', 
            display: 'block', 
            maxWidth: '100%', 
            marginLeft: 'auto', 
            marginRight: 'auto'
          }}>
            <Viewer
              fileUrl={url}
              defaultScale={getResponsiveScale()}
              theme="light"
              onDocumentLoad={() => setLoading(false)}
              onDocumentLoadFail={(error) => { setError(true); setLoading(false); console.error('Failed to load PDF:', url, error); }}
            />
          </div>
        </Worker>
      )}
                </div>
  );
}
