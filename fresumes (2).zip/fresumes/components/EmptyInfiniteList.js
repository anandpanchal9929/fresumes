/**
 * This component renders when we have no data returned from the infinite list search.
 */
import React, {StyleSheet, Text, View} from 'react-native';
import LightTheme from '../themes/LightTheme';

/**
 * @returns {React.ReactElement}
 */
export default function EmptyInfiniteList() {
    return <View style={styles.noResumesContainer}>
        <Text style={styles.bodyText}>No resumes found! Try another query.</Text>
    </View>
} 

const styles = StyleSheet.create({
    noResumesContainer: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    bodyText: {
        fontSize: 16,
        color: LightTheme.text
    }
});