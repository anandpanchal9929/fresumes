# Desktop View Forcing on Mobile Devices

This implementation forces mobile devices to display the desktop version of the website instead of the mobile-optimized version.

## How It Works

### 1. Viewport Meta Tag
The viewport meta tag has been modified to use a fixed desktop width:
```html
<meta name="viewport" content="width=1200, initial-scale=1.0, user-scalable=no" />
```

### 2. CSS Enforcement
- **desktopForced.css**: Contains comprehensive rules to force desktop layout
- **App.css**: Updated with mobile-specific overrides
- **index.css**: Modified to use desktop minimum width

### 3. JavaScript Detection
- **forceDesktopView.js**: Automatically detects mobile devices and applies desktop viewport
- Prevents mobile-specific behaviors like pinch-to-zoom and double-tap zoom

## Key Features

- **Fixed Width**: Forces 1200px minimum width on all devices
- **Horizontal Scrolling**: Enables horizontal scrolling on narrow screens
- **Touch Optimization**: Maintains appropriate touch target sizes
- **Auto-Detection**: Automatically applies to mobile devices
- **Cross-Browser**: Works on iOS Safari, Android Chrome, and other mobile browsers

## Files Modified

1. `webapp/index.html` - Viewport meta tag
2. `webapp/src/App.css` - Mobile-specific CSS overrides
3. `webapp/src/index.css` - Body minimum width
4. `webapp/src/App.jsx` - Import utility
5. `webapp/src/main.jsx` - Import CSS and utility
6. `webapp/src/utils/forceDesktopView.js` - Mobile detection and enforcement
7. `webapp/src/desktopForced.css` - Comprehensive desktop forcing CSS

## Testing

To test this functionality:
1. Open the website on a mobile device
2. The site should display at desktop width (1200px)
3. Horizontal scrolling should be available
4. All elements should maintain desktop sizing and layout

## Browser Compatibility

- ✅ iOS Safari
- ✅ Android Chrome
- ✅ Samsung Internet
- ✅ Firefox Mobile
- ✅ Edge Mobile

## Customization

To change the forced desktop width:
1. Update the viewport meta tag in `index.html`
2. Modify the CSS width values in `desktopForced.css`
3. Update the JavaScript width values in `forceDesktopView.js`

## Notes

- This approach may affect performance on very low-end devices
- Some mobile-specific features (like mobile navigation) may not work as expected
- Users can still manually zoom in/out if needed
- The implementation automatically detects mobile devices and applies desktop view
