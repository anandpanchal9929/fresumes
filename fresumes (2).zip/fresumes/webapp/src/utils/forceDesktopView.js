// Force desktop view on mobile devices
export const forceDesktopView = () => {
  // Detect if device is mobile
  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
                   (window.innerWidth <= 768 && window.innerHeight <= 1024);

  if (isMobile) {
    // Force desktop viewport
    const viewport = document.querySelector('meta[name="viewport"]');
    if (viewport) {
      viewport.setAttribute('content', 'width=1200, initial-scale=1.0, user-scalable=no');
    }

    // Add CSS to force desktop layout
    const style = document.createElement('style');
    style.textContent = `
      @media screen and (max-width: 1199px) {
        #root {
          min-width: 1200px !important;
          width: 1200px !important;
          margin: 0 auto !important;
          overflow-x: auto !important;
        }
        
        body {
          min-width: 1200px !important;
          overflow-x: auto !important;
        }
        
        html {
          min-width: 1200px !important;
          overflow-x: auto !important;
        }
        
        * {
          box-sizing: border-box;
        }
      }
    `;
    document.head.appendChild(style);

    // Prevent zoom on double tap
    let lastTouchEnd = 0;
    document.addEventListener('touchend', function (event) {
      const now = (new Date()).getTime();
      if (now - lastTouchEnd <= 300) {
        event.preventDefault();
      }
      lastTouchEnd = now;
    }, false);

    // Prevent pinch zoom
    document.addEventListener('gesturestart', function (e) {
      e.preventDefault();
    });

    document.addEventListener('gesturechange', function (e) {
      e.preventDefault();
    });

    document.addEventListener('gestureend', function (e) {
      e.preventDefault();
    });
  }
};

// Auto-execute when imported
if (typeof window !== 'undefined') {
  // Run after DOM is loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', forceDesktopView);
  } else {
    forceDesktopView();
  }
}
